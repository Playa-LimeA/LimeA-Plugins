// src/page.css
var page_default = ":host {\n  color: var(--foreground);\n  font-family: inherit;\n}\n* {\n  box-sizing: border-box;\n}\n[hidden] {\n  display: none !important;\n}\nh2 {\n  display: flex;\n  align-items: center;\n  gap: var(--ui-space-2);\n  font-size: var(--ui-text-base);\n  font-weight: 600;\n  margin: 0;\n  padding-bottom: var(--ui-space-3);\n  border-bottom: 1px solid var(--border);\n}\nh3 {\n  font-size: var(--ui-text-sm);\n  font-weight: 600;\n  margin: 0 0 var(--ui-space-1);\n}\np {\n  margin: 0;\n  font-size: var(--ui-text-sm);\n  line-height: var(--ui-leading-prose);\n  overflow-wrap: anywhere;\n}\n.intro {\n  margin-bottom: var(--ui-space-8);\n}\n.intro ul {\n  display: grid;\n  gap: var(--ui-space-2);\n  margin: 0;\n  padding: 0;\n  list-style: none;\n}\n.intro li {\n  position: relative;\n  padding-left: var(--ui-space-4);\n  color: var(--muted-foreground);\n  font-size: var(--ui-text-sm);\n  line-height: var(--ui-leading-prose);\n  overflow-wrap: anywhere;\n}\n.intro li::before {\n  content: '';\n  position: absolute;\n  top: 0.7em;\n  left: 0;\n  width: 0.25rem;\n  height: 0.25rem;\n  border-radius: 50%;\n  background: currentColor;\n}\n.intro strong {\n  color: var(--foreground);\n  font-weight: 600;\n}\n.section-icon,\n.feature-icon,\n.section-count {\n  color: var(--muted-foreground);\n}\n.section-icon,\n.feature-icon {\n  display: inline-flex;\n  flex: none;\n}\n.section-count {\n  font-size: var(--ui-text-sm);\n  font-weight: 400;\n}\n.features,\n.usage {\n  margin-top: var(--ui-space-8);\n}\n.features ul {\n  margin: 0;\n  padding: 0;\n  list-style: none;\n}\n.features li {\n  display: flex;\n  align-items: flex-start;\n  gap: var(--ui-space-4);\n  padding: var(--ui-space-5) 0 0;\n}\n.feature-icon {\n  width: 2.25rem;\n  min-height: 2.25rem;\n  align-items: center;\n  justify-content: center;\n}\n.features p {\n  color: var(--muted-foreground);\n}\n.usage p {\n  margin-top: var(--ui-space-4);\n  text-wrap: pretty;\n}\n.usage blockquote {\n  margin: var(--ui-space-3) 0 0;\n  padding: var(--ui-space-2) 0 var(--ui-space-2) var(--ui-space-4);\n  border-left: 2px solid var(--border);\n  font-size: var(--ui-text-sm);\n  line-height: var(--ui-leading-prose);\n  text-wrap: pretty;\n}\n";

// src/page-strings.mjs
var zh = {
  introLabel: "\u5B66\u4E60\u8BD5\u5377\u4F7F\u7528\u8BF4\u660E",
  intro: [
    ["\u6309\u5B66\u8FC7\u7684\u5185\u5BB9\u51FA\u5377\uFF1A", "\u5728\u5BF9\u8BDD\u91CC\u8BF4\u660E\u8003\u8BD5\u8303\u56F4\u548C\u8981\u6C42\uFF0C\u6750\u6599\u4E0D\u8DB3\u65F6\u5148\u786E\u8BA4\uFF0C\u518D\u51C6\u5907\u8BD5\u5377\u3002"],
    ["\u51C6\u5907\u597D\u518D\u8BA1\u65F6\uFF1A", "\u5148\u89C4\u5212\u9898\u578B\u4E0E\u5206\u503C\uFF0C\u9010\u9898\u7F16\u5199\u5E76\u6574\u5377\u5BA1\u6838\uFF1B\u70B9\u51FB\u5F00\u59CB\u8003\u8BD5\u540E\u624D\u5012\u8BA1\u65F6\u3002"],
    ["\u4EA4\u5377\u524D\u9690\u85CF\u7B54\u6848\uFF1A", "\u5728\u5B66\u4E60\u6A21\u5F0F\u53F3\u4FA7\u4E13\u5FC3\u4F5C\u7B54\uFF0C\u63D0\u4EA4\u540E\u67E5\u770B\u53C2\u8003\u7B54\u6848\u3001\u8BC4\u5206\u4E0E\u89E3\u6790\u3002"],
    ["\u8BB0\u5F55\u7559\u5728\u672C\u673A\uFF1A", "\u4F5C\u7B54\u81EA\u52A8\u4FDD\u5B58\uFF0C\u53EF\u4EE5\u56DE\u770B\u5386\u53F2\u8BD5\u5377\u3001\u91CD\u65B0\u8003\u8BD5\u6216\u56DE\u5230\u5BF9\u8BDD\u7EE7\u7EED\u8BB2\u89E3\u3002"]
  ],
  featuresTitle: "\u63D2\u4EF6\u529F\u80FD",
  features: [
    {
      icon: "message-square",
      title: "\u6839\u636E\u5B66\u4E60\u8303\u56F4\u51FA\u5377",
      detail: "\u4F7F\u7528\u5F53\u524D\u4F1A\u8BDD\u7684\u6A21\u578B\u51FA\u5377\u4E0E\u6279\u6539\uFF0C\u53EF\u8865\u5145\u77E5\u8BC6\u70B9\u3001\u96BE\u5EA6\u3001\u9898\u91CF\u548C\u65F6\u957F\u3002\u9ED8\u8BA4 10 \u9898\u300130 \u5206\u949F\u3001\u9002\u4E2D\u96BE\u5EA6\u3002"
    },
    {
      icon: "blocks",
      title: "\u9898\u578B\u4E0E\u5206\u503C\u89C4\u5212",
      detail: "\u652F\u6301\u5355\u9009\u3001\u591A\u9009\u3001\u5224\u65AD\u3001\u586B\u7A7A\u548C\u89E3\u7B54\u9898\uFF0C\u53EF\u6307\u5B9A\u5404\u9898\u578B\u6570\u91CF\u3002\u6BCF\u5377 3\u201320 \u9898\u30015\u2013180 \u5206\u949F\uFF0C\u603B\u5206 100 \u5206\u3002"
    },
    {
      icon: "shield-check",
      title: "\u9010\u9898\u7F16\u5199\uFF0C\u6574\u5377\u5BA1\u6838",
      detail: "\u5148\u56FA\u5B9A\u8BD5\u5377\u7ED3\u6784\uFF0C\u518D\u4F9D\u6B21\u751F\u6210\u9898\u76EE\uFF0C\u6700\u540E\u7EDF\u4E00\u6838\u5BF9\u7B54\u6848\u4E0E\u8BC4\u5206\u6807\u51C6\u3002\u6709\u95EE\u9898\u65F6\u5B9A\u5411\u4FEE\u8BA2\uFF0C\u8FDB\u5EA6\u4FDD\u5B58\u5728\u5F53\u524D\u8BD5\u5377\u4E2D\u3002"
    },
    {
      icon: "circle-dashed",
      title: "\u8BA1\u65F6\u6A21\u62DF\u8003\u8BD5",
      detail: "\u4E3B\u52A8\u5F00\u59CB\u540E\u8BA1\u65F6\uFF0C\u4EA4\u5377\u524D\u4E0D\u5C55\u793A\u7B54\u6848\u548C\u89E3\u6790\u3002\u53EF\u4EE5\u63D0\u524D\u4EA4\u5377\uFF0C\u5230\u65F6\u81EA\u52A8\u5C01\u5B58\u5DF2\u4FDD\u5B58\u7684\u4F5C\u7B54\uFF1B\u79BB\u5F00\u9875\u9762\u6216\u5173\u95ED\u5E94\u7528\u4E0D\u4F1A\u6682\u505C\u8003\u8BD5\u3002"
    },
    {
      icon: "list-tree",
      title: "\u7B54\u9898\u5BFC\u822A\u4E0E\u81EA\u52A8\u4FDD\u5B58",
      detail: "\u53F3\u4FA7\u7B54\u9898\u5361\u6309\u9898\u578B\u5FEB\u901F\u8DF3\u9898\uFF0C\u533A\u5206\u5DF2\u7B54\u3001\u672A\u7B54\u548C\u5F85\u68C0\u67E5\u9898\u76EE\u3002\u7A84\u7A97\u53E3\u53EF\u6536\u8D77\u5BFC\u822A\uFF0C\u4FDD\u5B58\u72B6\u6001\u6301\u7EED\u53EF\u89C1\uFF0C\u91CD\u542F\u540E\u53EF\u7EE7\u7EED\u672A\u5230\u65F6\u7684\u8003\u8BD5\u3002"
    },
    {
      icon: "file-text",
      title: "\u6279\u6539\u4E0E\u8003\u540E\u590D\u76D8",
      detail: "\u4EA4\u5377\u540E\u9010\u9898\u67E5\u770B\u5F97\u5206\u4E0E\u89E3\u6790\uFF0C\u89E3\u7B54\u9898\u652F\u6301\u8FC7\u7A0B\u5206\u3002\u4E0D\u786E\u5B9A\u9879\u6807\u4E3A\u5F85\u590D\u6838\uFF1B\u53EF\u56DE\u5230\u5BF9\u8BDD\u8BB2\u89E3\u6307\u5B9A\u9898\u76EE\uFF0C\u6216\u65B0\u5EFA\u4E00\u6B21\u91CD\u8003\u8BB0\u5F55\u3002"
    }
  ],
  usageTitle: "\u5F00\u59CB\u4F7F\u7528",
  usage: "\u542F\u7528\u63D2\u4EF6\u540E\uFF0C\u5207\u6362\u5230\u5B66\u4E60\u6A21\u5F0F\uFF0C\u4ECE\u53F3\u4FA7\u6253\u5F00\u300C\u8BD5\u5377\u300D\u3002\u70B9\u51FB\u300C\u8BD5\u5377\u300D\u5C06\u63D0\u793A\u6807\u8BB0\u52A0\u5165\u8F93\u5165\u6846\uFF0C\u8865\u5145\u8981\u6C42\u540E\u53D1\u9001\u3002\u8BD5\u5377\u51C6\u5907\u597D\u540E\u70B9\u51FB\u300C\u5F00\u59CB\u8003\u8BD5\u300D\uFF0C\u4EA4\u5377\u540E\u518D\u6279\u6539\u4E0E\u590D\u76D8\u3002\u4F60\u53EF\u4EE5\u8FD9\u6837\u8865\u5145\u8981\u6C42\uFF1A",
  example: "\u6839\u636E\u521A\u5B66\u8FC7\u7684\u4E00\u5143\u4E8C\u6B21\u65B9\u7A0B\u51FA\u4E00\u4EFD\u8BD5\u5377\uFF1A10 \u9898\u300130 \u5206\u949F\u3001\u9002\u4E2D\u96BE\u5EA6\u3002\u5355\u9009 4 \u9898\u3001\u591A\u9009 2 \u9898\u3001\u5224\u65AD 2 \u9898\u3001\u586B\u7A7A 1 \u9898\u3001\u89E3\u7B54 1 \u9898\uFF0C\u91CD\u70B9\u8003\u67E5\u5E94\u7528\u3002"
};
var en = {
  introLabel: "How Learning Exam works",
  intro: [
    [
      "Based on your learning: ",
      "Describe the scope and requirements in chat; missing context is clarified before the paper is prepared."
    ],
    [
      "Prepare before timing: ",
      "Question types and points are planned first, followed by questions and a whole-paper review. The timer starts when you begin."
    ],
    [
      "Answers stay hidden: ",
      "Take the exam beside your Learn chat, then view reference answers, marks and explanations after submission."
    ],
    [
      "Records stay local: ",
      "Responses are saved automatically. Revisit past papers, retake an exam or discuss a question in chat."
    ]
  ],
  featuresTitle: "Plugin features",
  features: [
    {
      icon: "message-square",
      title: "Papers based on your learning",
      detail: "Use the current conversation\u2019s model to create and mark papers. Add topics, difficulty, question count and duration. Defaults to 10 questions, 30 minutes and moderate difficulty."
    },
    {
      icon: "blocks",
      title: "Question types and points",
      detail: "Choose single choice, multiple choice, true or false, fill in the blanks and written answers. Set counts by type, with 3\u201320 questions, 5\u2013180 minutes and 100 points per paper."
    },
    {
      icon: "shield-check",
      title: "Generate questions, review the paper",
      detail: "Fix the structure, write each question, then review answers and marking criteria together. Issues receive targeted revisions, with progress saved to the paper."
    },
    {
      icon: "circle-dashed",
      title: "Timed mock exams",
      detail: "Start the timer yourself. Answers and explanations remain hidden until submission. Submit early or have saved responses sealed at the deadline; leaving the page or closing the app does not pause the exam."
    },
    {
      icon: "list-tree",
      title: "Question navigation and saving",
      detail: "Jump by question type and track answered, unanswered and flagged questions. Collapse navigation in narrow windows, check save status and resume after restarting before the deadline."
    },
    {
      icon: "file-text",
      title: "Marking and review",
      detail: "After submission, inspect marks and explanations for each question. Written answers support partial credit and uncertain results are flagged for review. Discuss a question in chat or create a separate retake."
    }
  ],
  usageTitle: "Get started",
  usage: "Enable the plugin, switch to Learn and open \u8BD5\u5377 (Exam) on the right. Click \u8BD5\u5377 to add its prompt label to the composer, add your requirements and send. Start when the paper is ready, then request marking after submission. For example:",
  example: "Create a moderate exam on the quadratic equations we just studied: 10 questions in 30 minutes, with 4 single choice, 2 multiple choice, 2 true or false, 1 fill in the blanks and 1 written answer. Focus on applications."
};

// src/page.mjs
function mount(container, context) {
  if (context.signal.aborted) return;
  const t = context.language.startsWith("zh") ? zh : en;
  const style = document.createElement("style");
  style.textContent = page_default;
  const root = document.createElement("div");
  root.className = "exam-page";
  root.innerHTML = `
    <section class="intro" aria-label=""><ul></ul></section>
    <section class="features" aria-labelledby="exam-features-title">
      <h2 id="exam-features-title"><span class="section-icon" data-icon="blocks"></span><span class="heading-label"></span><span class="section-count"></span></h2>
      <ul></ul>
    </section>
    <section class="usage" aria-labelledby="exam-usage-title">
      <h2 id="exam-usage-title"><span class="section-icon" data-icon="message-square"></span><span class="heading-label"></span></h2>
      <p></p><blockquote></blockquote>
    </section>`;
  container.replaceChildren(style, root);
  const query = (selector) => root.querySelector(selector);
  query(".intro").setAttribute("aria-label", t.introLabel);
  for (const [title, detail] of t.intro) {
    const item = document.createElement("li");
    const heading = document.createElement("strong");
    heading.textContent = title;
    const copy = document.createElement("span");
    copy.textContent = detail;
    item.append(heading, copy);
    query(".intro ul").append(item);
  }
  for (const { icon, title, detail } of t.features) {
    const item = document.createElement("li");
    const slot = document.createElement("span");
    slot.className = "feature-icon";
    slot.dataset.icon = icon;
    const copy = document.createElement("div");
    const heading = document.createElement("h3");
    heading.textContent = title;
    const description = document.createElement("p");
    description.textContent = detail;
    copy.append(heading, description);
    item.append(slot, copy);
    query(".features ul").append(item);
  }
  query(".features .heading-label").textContent = t.featuresTitle;
  query(".section-count").textContent = String(t.features.length);
  query(".usage .heading-label").textContent = t.usageTitle;
  query(".usage p").textContent = t.usage;
  query(".usage blockquote").textContent = t.example;
  const handles = [];
  for (const slot of root.querySelectorAll("[data-icon]")) {
    const name = slot.dataset.icon;
    if (context.controls?.icons?.includes(name))
      handles.push(context.controls.mount(slot, { type: "icon", name, size: 18 }));
    else slot.hidden = true;
  }
  let disposed = false;
  function cleanup() {
    if (disposed) return;
    disposed = true;
    context.signal.removeEventListener("abort", cleanup);
    for (const handle of handles) handle.destroy();
    root.remove();
    style.remove();
  }
  context.signal.addEventListener("abort", cleanup, { once: true });
  return cleanup;
}
export {
  mount
};
