// src/page.css
var page_default = ":host {\n  color: var(--foreground);\n  font-family: inherit;\n}\n* {\n  box-sizing: border-box;\n}\n[hidden] {\n  display: none !important;\n}\nh2 {\n  display: flex;\n  align-items: center;\n  gap: var(--ui-space-2);\n  font-size: var(--ui-text-base);\n  font-weight: 600;\n  margin: 0;\n  padding-bottom: var(--ui-space-3);\n  border-bottom: 1px solid var(--border);\n}\nh3 {\n  font-size: var(--ui-text-sm);\n  font-weight: 600;\n  margin: 0 0 var(--ui-space-1);\n}\np {\n  margin: 0;\n  font-size: var(--ui-text-sm);\n  line-height: var(--ui-leading-prose);\n  overflow-wrap: anywhere;\n}\n.section-icon,\n.feature-icon {\n  display: inline-flex;\n  flex: none;\n  color: var(--muted-foreground);\n}\n.feature-icon {\n  margin-top: 0.125rem;\n}\n.account-row {\n  display: flex;\n  align-items: center;\n  flex-wrap: wrap;\n  gap: var(--ui-space-4);\n  padding: var(--ui-space-5) 0 0;\n}\n.account-icon {\n  width: 2.25rem;\n  height: 2.25rem;\n  border: 1px solid var(--border);\n  border-radius: var(--ui-radius-md);\n  flex: none;\n}\n.account-summary {\n  flex: 1;\n  min-width: min(100%, 14rem);\n}\n.account-name {\n  display: block;\n  font-size: var(--ui-text-sm);\n  line-height: var(--ui-leading-prose);\n  overflow-wrap: anywhere;\n}\n.account-hint {\n  margin-top: var(--ui-space-1);\n  color: var(--muted-foreground);\n}\n.account-actions {\n  display: flex;\n  flex-wrap: wrap;\n  gap: var(--ui-space-2);\n}\n.account-status {\n  margin-top: var(--ui-space-4);\n  color: var(--muted-foreground);\n}\n.account-error {\n  margin-top: var(--ui-space-4);\n}\n.account-error p {\n  color: var(--destructive);\n  margin-bottom: var(--ui-space-2);\n}\n.features {\n  margin-top: var(--ui-space-8);\n}\n.features ul {\n  margin: 0;\n  padding: 0;\n  list-style: none;\n}\n.features li {\n  display: flex;\n  align-items: flex-start;\n  gap: var(--ui-space-4);\n  padding: var(--ui-space-5) 0 0;\n}\n.features p {\n  color: var(--muted-foreground);\n}\n";

// src/strings.mjs
var zh = {
  accountTitle: "\u767E\u5EA6\u7F51\u76D8\u8D26\u53F7",
  loading: "\u6B63\u5728\u8BFB\u53D6\u8FDE\u63A5\u72B6\u6001",
  notConnected: "\u672A\u8FDE\u63A5\u767E\u5EA6\u7F51\u76D8",
  authorizing: "\u7B49\u5F85\u767E\u5EA6\u7F51\u76D8\u6388\u6743",
  authorizingHint: "\u8BF7\u5728\u7CFB\u7EDF\u6D4F\u89C8\u5668\u4E2D\u767B\u5F55\u767E\u5EA6\u8D26\u53F7\u5E76\u540C\u610F\u6388\u6743\uFF0C\u5B8C\u6210\u540E\u56DE\u5230 LimeA\u3002",
  reauthorization: "\u9700\u8981\u91CD\u65B0\u8FDE\u63A5\u767E\u5EA6\u7F51\u76D8",
  ready: "\u5DF2\u8FDE\u63A5",
  scope: "\u6388\u6743\u76EE\u5F55\u6D4F\u89C8\u3001\u641C\u7D22\u3001\u914D\u989D\u67E5\u770B\u4E0E\u6587\u4EF6\u6574\u7406\uFF08\u4E2A\u4EBA\u5E94\u7528\u9ED8\u8BA4\u4F4D\u4E8E /apps/<\u5E94\u7528\u540D>/\uFF09",
  connect: "\u8FDE\u63A5\u767E\u5EA6\u7F51\u76D8",
  continue: "\u7EE7\u7EED\u6388\u6743",
  cancel: "\u53D6\u6D88\u6388\u6743",
  refresh: "\u5237\u65B0\u4EE4\u724C",
  disconnect: "\u65AD\u5F00\u8FDE\u63A5",
  retry: "\u91CD\u8BD5",
  savedAcknowledging: "\u5DF2\u4FDD\u5B58\u8FDE\u63A5\uFF0C\u6B63\u5728\u5411\u6388\u6743\u7F51\u5173\u786E\u8BA4\u3002",
  recoveryHint: "\u8FDE\u63A5\u6216\u6388\u6743\u72B6\u6001\u4ECD\u5F85\u540C\u6B65\uFF0C\u53EF\u5237\u65B0\u4EE4\u724C\u6216\u91CD\u65B0\u6388\u6743\u3002",
  loadFailed: "\u65E0\u6CD5\u8BFB\u53D6\u767E\u5EA6\u7F51\u76D8\u8FDE\u63A5\u72B6\u6001\uFF0C\u8BF7\u91CD\u8BD5\u3002",
  actionFailed: "\u672C\u6B21\u8FDE\u63A5\u64CD\u4F5C\u672A\u5B8C\u6210\uFF0C\u8BF7\u91CD\u8BD5\u3002",
  vaultUnavailable: "\u7CFB\u7EDF\u5B89\u5168\u5B58\u50A8\u5F53\u524D\u4E0D\u53EF\u7528\uFF0C\u65E0\u6CD5\u4FDD\u5B58\u767E\u5EA6\u7F51\u76D8\u51ED\u636E\u3002",
  revocation: {
    not_requested: "",
    pending: "\u5DF2\u65AD\u5F00\u672C\u5730\u8FDE\u63A5\uFF0C\u6B63\u5728\u6E05\u7406\u6388\u6743\u72B6\u6001\u3002",
    confirmed: "\u5DF2\u65AD\u5F00\u672C\u5730\u8FDE\u63A5\u3002",
    unknown: "\u5DF2\u65AD\u5F00\u672C\u5730\u8FDE\u63A5\uFF1B\u767E\u5EA6\u7F51\u76D8\u4E0D\u652F\u6301\u81EA\u52A8\u8FDC\u7AEF\u64A4\u9500\uFF0C\u53EF\u524D\u5F80\u767E\u5EA6\u8D26\u53F7\u6388\u6743\u7BA1\u7406\u9875\u9762\u624B\u52A8\u79FB\u9664\u6388\u6743\u3002",
    failed: "\u5DF2\u65AD\u5F00\u672C\u5730\u8FDE\u63A5\uFF0C\u8BF7\u524D\u5F80\u767E\u5EA6\u8D26\u53F7\u6388\u6743\u7BA1\u7406\u9875\u9762\u786E\u8BA4\u662F\u5426\u9700\u8981\u624B\u52A8\u79FB\u9664\u6388\u6743\u3002"
  },
  auth: {
    failed: "\u672A\u5B8C\u6210\u767E\u5EA6\u7F51\u76D8\u6388\u6743\uFF0C\u53EF\u91CD\u65B0\u53D1\u8D77\u8FDE\u63A5\u3002",
    expired: "\u672C\u6B21\u6388\u6743\u5DF2\u8FC7\u671F\uFF0C\u8BF7\u91CD\u65B0\u53D1\u8D77\u8FDE\u63A5\u3002",
    unknown: "\u6388\u6743\u7ED3\u679C\u672A\u80FD\u786E\u8BA4\uFF0C\u8BF7\u5148\u68C0\u67E5\u662F\u5426\u5DF2\u6388\u6743\u540E\u518D\u8BD5\u3002",
    cancelled: "\u5DF2\u53D6\u6D88\u672C\u6B21\u6388\u6743\u3002"
  },
  featuresTitle: "\u7F51\u76D8\u6D4F\u89C8\u4E0E\u6574\u7406\u80FD\u529B",
  features: [
    ["\u6D4F\u89C8\u4E0E\u641C\u7D22\u76EE\u5F55", "\u5217\u51FA\u6388\u6743\u76EE\u5F55\u6587\u4EF6\u3001\u6309\u5173\u952E\u5B57\u9012\u5F52\u68C0\u7D22\uFF0C\u5E76\u67E5\u770B\u7A7A\u95F4\u5BB9\u91CF\u4E0E\u6587\u4EF6\u5143\u6570\u636E\u3002"],
    ["\u5B89\u5168\u6574\u7406\u6587\u4EF6", "\u652F\u6301\u65B0\u5EFA\u6587\u4EF6\u5939\u3001\u91CD\u547D\u540D\u3001\u79FB\u52A8\u3001\u590D\u5236\u4E0E\u5220\u9664\uFF0C\u5199\u5165\u524D\u8DDF\u968F\u4F1A\u8BDD\u6743\u9650\u5BA1\u6279\u3002"],
    ["\u6C99\u7BB1\u76EE\u5F55\u9694\u79BB", "\u4E2A\u4EBA\u5E94\u7528\u9ED8\u8BA4\u4EC5\u8BBF\u95EE\u4E13\u5C5E\u76EE\u5F55 /apps/<\u5E94\u7528\u540D>/\uFF0C\u4E14\u4E0D\u66B4\u9732\u4E0B\u8F7D\u76F4\u94FE\u3002"]
  ]
};
var en = {
  accountTitle: "Baidu Netdisk account",
  loading: "Checking connection",
  notConnected: "Baidu Netdisk not connected",
  authorizing: "Waiting for Baidu Netdisk authorization",
  authorizingHint: "Sign in to Baidu in your browser and approve access, then return to LimeA.",
  reauthorization: "Reconnection required",
  ready: "Connected",
  scope: "Directory browse, search, quota & file organization (personal apps default to /apps/<app>/)",
  connect: "Connect Baidu Netdisk",
  continue: "Continue authorization",
  cancel: "Cancel",
  refresh: "Refresh token",
  disconnect: "Disconnect",
  retry: "Retry",
  savedAcknowledging: "Connection saved; confirming with the authorization gateway.",
  recoveryHint: "Connection state is still syncing. Refresh or reconnect if needed.",
  loadFailed: "Could not load Baidu Netdisk connection status.",
  actionFailed: "Could not complete that connection action. Try again.",
  vaultUnavailable: "System secure storage is unavailable, so credentials cannot be saved.",
  revocation: {
    not_requested: "",
    pending: "Disconnected locally; finalizing cleanup.",
    confirmed: "Disconnected locally.",
    unknown: "Disconnected locally. Baidu Netdisk does not support automatic remote revocation; remove access in your Baidu account settings if needed.",
    failed: "Disconnected locally. Check your Baidu account authorization settings to remove access if needed."
  },
  auth: {
    failed: "Authorization did not finish. Try connecting again.",
    expired: "Authorization expired. Start a new connection.",
    unknown: "Authorization outcome could not be confirmed. Check your account and try again.",
    cancelled: "Authorization cancelled."
  },
  featuresTitle: "Drive & file capabilities",
  features: [
    [
      "Browse and search files",
      "List authorized folders, search recursively by keyword, and inspect quota and file metadata."
    ],
    [
      "Organize files safely",
      "Create folders, rename, move, copy and delete files with session-level approval controls."
    ],
    [
      "Scoped app directory",
      "Personal apps are scoped to /apps/<app>/ and never expose raw download links."
    ]
  ]
};

// src/page.mjs
function mount(container, context) {
  if (!context.connections || !context.controls) throw new Error("plugin-host-upgrade-required");
  const t = context.language.startsWith("zh") ? zh : en;
  const style = document.createElement("style");
  style.textContent = page_default;
  const root = document.createElement("div");
  root.className = "baidu-netdisk-page";
  root.innerHTML = `<section class="account" aria-labelledby="account-title">
    <h2 id="account-title"></h2>
    <div class="account-row"><img class="account-icon" alt=""><div class="account-summary"><strong class="account-name"></strong><p class="account-hint"></p></div>
      <div class="account-actions"><span data-action="authorize"></span><span data-action="resume"></span><span data-action="cancel"></span><span data-action="refresh"></span><span data-action="disconnect"></span></div></div>
    <p role="status" class="account-status"></p><div role="alert" class="account-error"><p></p><span data-action="retry"></span></div></section>
    <section class="features"><h2><span class="section-icon" data-icon="blocks"></span><span class="heading-label"></span></h2><ul></ul></section>`;
  container.replaceChildren(style, root);
  const query = (selector) => root.querySelector(selector);
  query("#account-title").textContent = t.accountTitle;
  query(".account-icon").src = new URL("assets/icon.png", context.resourceBase).href;
  query(".features h2 .heading-label").textContent = t.featuresTitle;
  const featureIcons = ["search", "circle-check", "list-tree"];
  for (const [index, [title, detail]] of t.features.entries()) {
    const row = document.createElement("li"), icon = document.createElement("span"), section = document.createElement("div"), h = document.createElement("h3"), p = document.createElement("p");
    h.textContent = title;
    p.textContent = detail;
    icon.className = "feature-icon";
    icon.dataset.icon = featureIcons[index];
    section.append(h, p);
    row.append(icon, section);
    query(".features ul").append(row);
  }
  let view, pending = false, polling = false, timer, disposed = false, error = "";
  const handles = /* @__PURE__ */ new Map();
  const iconHandles = [];
  for (const slot of root.querySelectorAll("[data-icon]")) {
    const name = slot.dataset.icon;
    if (context.controls.icons?.includes(name)) {
      iconHandles.push(context.controls.mount(slot, { type: "icon", name, size: 18 }));
    } else slot.hidden = true;
  }
  const alive = () => !disposed && !context.signal.aborted;
  const labels = {
    authorize: t.connect,
    resume: t.continue,
    cancel: t.cancel,
    refresh: t.refresh,
    disconnect: t.disconnect,
    retry: t.retry
  };
  const actionIcons = {
    authorize: "external-link",
    resume: "external-link",
    refresh: "refresh-cw",
    disconnect: "unplug"
  };
  const buttonIcon = (action) => context.controls.icons?.includes(actionIcons[action]) ? { icon: actionIcons[action] } : {};
  for (const [action, label] of Object.entries(labels)) {
    const slot = query(`[data-action="${action}"]`);
    handles.set(
      action,
      context.controls.mount(slot, {
        type: "button",
        label,
        ...buttonIcon(action),
        variant: action === "authorize" ? "default" : "outline",
        onPress: () => void perform(action)
      })
    );
  }
  function render() {
    if (!alive()) return;
    const c = view?.connection, f = view?.authorization;
    const authorizing = f && ["preparing", "authorizing"].includes(f.status);
    const connected = c?.status === "connected";
    query(".account-name").textContent = !view ? t.loading : authorizing ? t.authorizing : connected ? c.workspaceName : c?.status === "reauthorization_required" ? t.reauthorization : t.notConnected;
    query(".account-hint").textContent = authorizing ? t.authorizingHint : connected ? `${t.ready} \xB7 ${t.scope}` : t.scope;
    const shown = {
      authorize: Boolean(
        view && (!c || c.status === "disconnected") && !authorizing && f?.status !== "persisted"
      ),
      resume: Boolean(authorizing),
      cancel: Boolean(authorizing),
      refresh: Boolean(c && c.status !== "disconnected" && c.expiryKnowledge === "known"),
      disconnect: Boolean(c && c.status !== "disconnected"),
      retry: Boolean(error)
    };
    for (const [action, handle] of handles) {
      query(`[data-action="${action}"]`).hidden = !shown[action];
      handle.update({
        type: "button",
        label: labels[action],
        ...buttonIcon(action),
        variant: action === "authorize" ? "default" : "outline",
        disabled: pending || action === "refresh" && Boolean(view?.operation),
        onPress: () => void perform(action)
      });
    }
    let status = "";
    if (c?.status === "disconnected") status = t.revocation[c.remoteRevocation];
    else if (f?.status === "persisted") status = t.savedAcknowledging;
    else if (f && ["failed", "expired", "unknown", "cancelled"].includes(f.status))
      status = t.auth[f.status];
    else if (c?.error || f?.error) status = t.recoveryHint;
    query(".account-status").textContent = status;
    query(".account-status").hidden = !status;
    query(".account-error").hidden = !error;
    query(".account-error p").textContent = error;
    query(".account").setAttribute("aria-busy", String(pending || !view));
  }
  function schedule() {
    clearTimeout(timer);
    if (alive() && (view?.operation || view?.authorization?.pending))
      timer = setTimeout(() => void load(), 2e3);
  }
  async function load() {
    if (!alive() || pending || polling) return;
    polling = true;
    try {
      const next = await context.connections.request({ action: "view" });
      if (alive() && (!view || next.revision >= view.revision)) {
        view = next;
        error = "";
      }
    } catch {
      if (alive()) error = t.loadFailed;
    } finally {
      polling = false;
      if (alive()) {
        render();
        schedule();
      }
    }
  }
  async function perform(action) {
    if (!alive() || pending) return;
    if (action === "retry") {
      await load();
      return;
    }
    pending = true;
    error = "";
    render();
    try {
      const next = await context.connections.request({ action });
      if (alive() && (!view || next.revision >= view.revision)) view = next;
    } catch (e) {
      if (alive())
        error = e?.code === "connection-vault-unavailable" ? t.vaultUnavailable : t.actionFailed;
    } finally {
      pending = false;
      if (alive()) {
        render();
        schedule();
      }
    }
  }
  const unsubscribe = context.connections.subscribe((next) => {
    if (alive() && (!view || next.revision >= view.revision)) {
      view = next;
      render();
      schedule();
    }
  });
  const onFocus = () => void load();
  window.addEventListener("focus", onFocus);
  function cleanup() {
    disposed = true;
    clearTimeout(timer);
    unsubscribe();
    window.removeEventListener("focus", onFocus);
    for (const handle of handles.values()) handle.destroy();
    for (const handle of iconHandles) handle.destroy();
    container.replaceChildren();
  }
  context.signal.addEventListener("abort", cleanup, { once: true });
  render();
  void load();
  return cleanup;
}
export {
  mount
};
