// src/game.mjs
import { randomUUID, randomInt } from "node:crypto";

// src/prompts.mjs
var object = (properties, required = Object.keys(properties)) => ({
  type: "object",
  properties,
  required,
  additionalProperties: false
});
var text = (maxLength) => ({ type: "string", maxLength });
var wordsSchema = object({
  words: {
    type: "array",
    minItems: 6,
    maxItems: 18,
    items: object({
      word: { ...text(8), minLength: 1 },
      aliases: { type: "array", maxItems: 4, items: text(12) }
    })
  }
});
var choiceSchema = object({ choice: { type: "integer", minimum: 1, maximum: 3 } });
var guessSchema = object({ guess: text(24) });
var number = (max) => ({ type: "number", minimum: 0, maximum: max });
var color = { type: "string", pattern: "^#[0-9a-fA-F]{6}$" };
var drawSchema = object({
  add: {
    type: "array",
    maxItems: 24,
    items: object({
      kind: { type: "string", enum: ["line", "ellipse", "rectangle"] },
      x: number(800),
      y: number(600),
      width: number(800),
      height: number(600),
      points: { type: "array", maxItems: 400, items: number(800) },
      color,
      fill: { type: "string", pattern: "^(#[0-9a-fA-F]{6}|transparent)$" },
      strokeWidth: { type: "number", minimum: 1, maximum: 24 }
    })
  },
  remove: { type: "array", maxItems: 24, items: text(64) },
  done: { type: "boolean" }
});
var wordPrompt = (used) => `\u4F60\u662F\u4F60\u753B\u6211\u731C\u7684\u72EC\u7ACB\u51FA\u9898\u5458\uFF0C\u4E0D\u53C2\u4E0E\u731C\u753B\u3002\u751F\u621012\u4E2A\u9002\u5408\u7B80\u7B14\u753B\u7684\u5E38\u89C1\u3001\u5177\u4F53\u4E2D\u6587\u540D\u8BCD\uFF0C\u6BCF\u4E2A1\u81F36\u5B57\uFF0C\u8986\u76D6\u7269\u54C1\u3001\u52A8\u7269\u3001\u98DF\u7269\u6216\u81EA\u7136\u4E8B\u7269\u3002\u4E0D\u8981\u957F\u53E5\u3001\u751F\u50FB\u540D\u79F0\u3001\u6587\u5B57\u8C1C\u8BED\u3001\u62BD\u8C61\u6982\u5FF5\u3002\u6BCF\u4E2A\u8BCD\u53EF\u9644\u5C11\u91CF\u786E\u5207\u540C\u4E49\u8BCD\uFF0C\u4E0D\u80FD\u7528\u5BBD\u6CDB\u7C7B\u522B\u4F5C\u540C\u4E49\u8BCD\u3002\u907F\u514D\u8FD9\u4E9B\u5DF2\u7ECF\u5C55\u793A\u8FC7\u7684\u8BCD\uFF1A${JSON.stringify(used)}\u3002\u53EA\u63D0\u4EA4words\u7ED3\u6784\u5316\u7ED3\u679C\u3002`;
var choicePrompt = (choices) => `\u4F60\u662F\u672C\u8F6E\u753B\u5BB6\uFF0C\u7528\u6237\u8D1F\u8D23\u731C\u3002\u79D8\u5BC6\u5019\u9009\uFF1A${JSON.stringify(choices.map((v) => v.word))}\u3002\u9009\u62E9\u4F60\u60F3\u753B\u7684\u4E00\u4E2A\uFF0C\u8FD4\u56DEchoice\uFF081\u52303\uFF09\uFF0C\u4E0D\u8BF4\u51FA\u9898\u76EE\u3002`;
var guessPrompt = (guesses, characterCount) => `\u4F60\u6B63\u548C\u7528\u6237\u73A9\u4F60\u753B\u6211\u731C\u3002\u4F60\u662F\u731C\u6D4B\u8005\uFF0C\u7528\u6237\u662F\u753B\u5BB6\u3002\u53EA\u89C2\u5BDF\u6240\u9644\u5B9E\u9645\u753B\u9762\uFF0C\u4E0D\u77E5\u9053\u9898\u76EE\u3002\u5B57\u6570\u63D0\u793A\uFF1A\u6807\u51C6\u9898\u76EE\u5171${characterCount}\u4E2A\u5B57\u3002\u8BF7\u7ED3\u5408\u5B57\u6570\u731C\u4E00\u4E2A\u6700\u53EF\u80FD\u7684\u5177\u4F53\u4E2D\u6587\u540D\u8BCD\uFF1B\u786E\u5207\u540C\u4E49\u8BCD\u5B57\u6570\u53EF\u4EE5\u4E0D\u540C\uFF1B\u4FE1\u606F\u4E0D\u8DB3\u53EF\u8FD4\u56DE\u7A7Aguess\u3002\u4E0D\u8981\u63CF\u8FF0\u7B54\u6848\u6765\u81EA\u7CFB\u7EDF\u6216\u7F16\u9020\u770B\u5230\u7684\u7EC6\u8282\u3002\u4E0D\u91CD\u590D\u5DF2\u731C\u8FC7\u7684\uFF1A${JSON.stringify(guesses.map((v) => v.text))}\u3002`;
var drawPrompt = (state) => `\u4F60\u6B63\u548C\u7528\u6237\u73A9\u4F60\u753B\u6211\u731C\uFF0C\u4F60\u662F\u753B\u5BB6\u3002\u79C1\u5BC6\u9898\u76EE\uFF1A${state.answer.word}\u3002\u4E0D\u8981\u5199\u51FA\u4EFB\u4F55\u6587\u5B57\u3001\u5B57\u6BCD\u6216\u6570\u5B57\u63D0\u793A\u7B54\u6848\u3002\u767D\u8272\u753B\u677F800\xD7600\uFF0C\u539F\u70B9\u5DE6\u4E0A\uFF0Cx\u5411\u53F3y\u5411\u4E0B\u3002\u770B\u6240\u9644\u7684\u5B9E\u9645\u753B\u9762\uFF0C\u51B3\u5B9A\u4E0B\u4E00\u6279\u7ED8\u753B\uFF1B\u62BD\u8C61\u548C\u7B28\u62D9\u4E5F\u6CA1\u5173\u7CFB\u3002\u7528\u57FA\u7840\u56FE\u5F62\u8868\u8FBE\uFF0C\u5148\u753B\u8F6E\u5ED3\uFF0C\u518D\u8865\u7EC6\u8282\u3002line\u7684points\u4E3A\u7EDD\u5BF9\u5750\u6807[x,y,x,y,...]\uFF0C\u6B64\u65F6x/y/width/height\u586B0\uFF1Bellipse\u548Crectangle\u7528\u5DE6\u4E0A\u89D2x/y\u53CAwidth/height\uFF0Cpoints\u586B[]\u3002fill\u7528transparent\u6216\u516D\u4F4D\u5341\u516D\u8FDB\u5236\u989C\u8272\uFF0CstrokeWidth\u4E3A1\u523024\u3002\u53EFremove\u5DF2\u6709\u5143\u7D20\uFF0C\u518Dadd\u66FF\u4EE3\u5B83\u3002\u5DF2\u6709\u5143\u7D20\uFF1A${JSON.stringify(state.scene.shapes)}\u3002\u7528\u6237\u731C\u8FC7\uFF1A${JSON.stringify(state.guesses.map((v) => v.text))}\u3002${state.drawingError ?? ""} \u8FD4\u56DEadd\u3001remove\u3001done\uFF1B\u753B\u5F97\u591F\u4E86\u5C31done=true\u7B49\u5F85\u7528\u6237\uFF0C\u65E0\u9700\u4E0D\u65AD\u91CD\u590D\u6DFB\u52A0\u3002`;
var normalize = (value) => String(value).normalize("NFKC").toLowerCase().replace(/[\s\p{P}\p{S}]/gu, "");
var wordLength = (word) => [...normalize(word)].length;
function validWords(value, used) {
  const seen = new Set(used.map(normalize));
  return value.words.filter((item) => {
    const word = normalize(item.word);
    if (!word || [...word].length > 6 || seen.has(word)) return false;
    seen.add(word);
    return true;
  }).map((item) => ({ word: item.word.trim(), aliases: item.aliases.filter((s) => normalize(s)) }));
}

// src/game.mjs
var migrations = [
  {
    id: "1000_initial",
    sql: `
CREATE TABLE games(session_id TEXT PRIMARY KEY, state TEXT NOT NULL CHECK(json_valid(state)));
CREATE TABLE preferences(id INTEGER PRIMARY KEY CHECK(id=1), value TEXT NOT NULL CHECK(json_valid(value)));
CREATE TABLE rounds(id TEXT PRIMARY KEY, session_id TEXT NOT NULL, ended_at INTEGER NOT NULL, record TEXT NOT NULL CHECK(json_valid(record)));
CREATE INDEX rounds_session ON rounds(session_id,ended_at DESC);
CREATE TABLE requests(id TEXT PRIMARY KEY, session_id TEXT NOT NULL, round_id TEXT NOT NULL, purpose TEXT NOT NULL, status TEXT NOT NULL, started_at INTEGER NOT NULL, ended_at INTEGER, input TEXT NOT NULL, output TEXT, usage TEXT);
`
  }
];
var blank = () => ({ version: 1, shapes: [] });
var defaults = { duration: 300, firstPainter: "human" };
var publicSummary = ({ scene: _scene, guesses, ...item }) => ({
  ...item,
  guesses: guesses.slice(-12),
  guessCount: guesses.length
});
var settingsValue = (value) => {
  if (!value || ![180, 300, 600].includes(value.duration) || !["human", "model"].includes(value.firstPainter))
    throw new Error("invalid-settings");
  return { duration: value.duration, firstPainter: value.firstPainter };
};
var publicState = (state) => state ? {
  id: state.id,
  round: state.round,
  phase: state.phase,
  painter: state.painter,
  scene: state.scene,
  canvasRevision: state.canvasRevision,
  epoch: state.epoch,
  deadline: state.deadline,
  remaining: state.remaining,
  duration: state.duration,
  guesses: state.guesses,
  result: state.result,
  error: state.error,
  thinking: Boolean(state.pending),
  choices: state.painter === "human" && state.phase === "choosing" ? state.choices.map((v) => v.word) : [],
  word: state.painter === "human" || state.result ? state.answer?.word ?? null : null,
  characterCount: state.answer ? wordLength(state.answer.word) : null
} : null;
async function createGame(db, { validateCanvas, now = Date.now } = {}) {
  let queue = Promise.resolve(), closed = false;
  const running = /* @__PURE__ */ new Map();
  const serial = (action) => {
    if (closed) return Promise.reject(new Error("game-closed"));
    const work = queue.then(action);
    queue = work.catch(() => {
    });
    return work;
  };
  const scope = (context) => {
    if (context?.mode !== "chat" || typeof context.sessionId !== "string" || !context.sessionId || context.sessionId.length > 128)
      throw new Error("invalid-game-scope");
    return context.sessionId;
  };
  const read = async (id) => {
    const row = await db.get("SELECT state FROM games WHERE session_id=?", [id]);
    return row ? JSON.parse(row.state) : null;
  };
  const settings = async () => {
    const row = await db.get("SELECT value FROM preferences WHERE id=1");
    return row ? settingsValue(JSON.parse(row.value)) : { ...defaults };
  };
  const write = async (id, state) => {
    await db.run(
      "INSERT INTO games(session_id,state) VALUES (?,?) ON CONFLICT(session_id) DO UPDATE SET state=excluded.state",
      [id, JSON.stringify(state)]
    );
    running.get(id)?.wake?.();
  };
  const history = async (id) => (await db.all(
    "SELECT record FROM rounds WHERE session_id=? ORDER BY ended_at DESC,rowid DESC LIMIT 5",
    [id]
  )).map((row) => JSON.parse(row.record));
  const record = (state) => ({
    round: state.round,
    painter: state.painter,
    answer: state.answer?.word ?? null,
    result: state.result,
    guesses: state.guesses,
    scene: state.scene
  });
  const archive = async (id, state) => {
    const summary = record(state);
    await db.transaction([
      {
        sql: "INSERT INTO games(session_id,state) VALUES (?,?) ON CONFLICT(session_id) DO UPDATE SET state=excluded.state",
        params: [id, JSON.stringify(state)]
      },
      {
        sql: "INSERT OR IGNORE INTO rounds(id,session_id,ended_at,record) VALUES (?,?,?,?)",
        params: [state.id, id, now(), JSON.stringify(summary)]
      }
    ]);
    running.get(id)?.wake?.();
  };
  const cancel = (id) => {
    running.get(id)?.request?.abort();
    running.get(id)?.wake?.();
  };
  const finishRound = async (id, state, result) => {
    if (!["drawing", "preparing", "ready"].includes(state.phase)) return;
    state.phase = "result";
    state.result = result;
    state.deadline = null;
    state.pending = null;
    state.epoch++;
    await archive(id, state);
    cancel(id);
  };
  const pause = async (id, state, reason) => {
    if (!state || ["paused", "ended"].includes(state.phase)) return;
    state.pausedPhase = state.phase;
    state.remaining = state.deadline ? Math.max(0, state.deadline - now()) : state.remaining;
    state.deadline = null;
    state.phase = "paused";
    state.pending = null;
    state.error = reason;
    state.epoch++;
    await write(id, state);
    cancel(id);
  };
  const next = (state, painter) => ({
    ...state,
    id: randomUUID(),
    round: (state?.round ?? 0) + 1,
    painter,
    phase: "preparing",
    choices: [],
    answer: null,
    result: null,
    guesses: [],
    scene: blank(),
    canvasRevision: 0,
    epoch: (state?.epoch ?? 0) + 1,
    deadline: null,
    remaining: (state?.duration ?? 300) * 1e3,
    pending: null,
    error: null,
    drawn: false,
    waiting: false,
    drawingCorrections: 0,
    drawingError: null,
    observed: -1,
    observedGuesses: -1
  });
  await db.run("UPDATE requests SET status='interrupted',ended_at=? WHERE status='running'", [
    now()
  ]);
  for (const row of await db.all("SELECT session_id,state FROM games")) {
    await pause(row.session_id, JSON.parse(row.state), "interrupted");
  }
  async function wait(runtime, milliseconds = 1e3) {
    if (runtime.signal.aborted) return;
    await new Promise((resolve) => {
      const done = () => {
        clearTimeout(timer);
        runtime.signal.removeEventListener("abort", done);
        if (runtime.wake === done) runtime.wake = null;
        resolve();
      };
      const timer = setTimeout(done, milliseconds);
      runtime.wake = done;
      runtime.signal.addEventListener("abort", done, { once: true });
    });
  }
  async function request(id, runtime, state, purpose, prompt, outputSchema, image) {
    const requestId = randomUUID(), controller = new AbortController();
    runtime.request = controller;
    const token = { round: state.id, epoch: state.epoch };
    const ready = await serial(async () => {
      const latest = await read(id);
      if (latest.id !== token.round || latest.epoch !== token.epoch || latest.phase === "paused" || latest.phase === "ended")
        return false;
      latest.pending = purpose;
      await db.transaction([
        {
          sql: "INSERT INTO requests(id,session_id,round_id,purpose,status,started_at,input) VALUES (?,?,?,?,?,?,?)",
          params: [
            requestId,
            id,
            state.id,
            purpose,
            "running",
            now(),
            JSON.stringify({ prompt, canvasRevision: state.canvasRevision })
          ]
        },
        {
          sql: "UPDATE games SET state=? WHERE session_id=?",
          params: [JSON.stringify(latest), id]
        }
      ]);
      return true;
    });
    if (!ready) {
      runtime.request = null;
      return null;
    }
    let answer;
    try {
      answer = await runtime.model.request(
        {
          inheritCharacter: purpose !== "words",
          prompt,
          outputSchema,
          ...image ? { image } : {}
        },
        AbortSignal.any([runtime.signal, controller.signal])
      );
      return await serial(async () => {
        const latest = await read(id);
        const valid = !runtime.signal.aborted && !controller.signal.aborted && latest.id === token.round && latest.epoch === token.epoch && !["paused", "ended", "result"].includes(latest.phase);
        await db.run("UPDATE requests SET status=?,ended_at=?,output=?,usage=? WHERE id=?", [
          valid ? "succeeded" : "discarded",
          now(),
          JSON.stringify(answer.value),
          JSON.stringify(answer.usage),
          requestId
        ]);
        if (!valid) return null;
        latest.pending = null;
        await write(id, latest);
        return { value: answer.value, state: latest };
      });
    } catch (error) {
      await serial(async () => {
        await db.run("UPDATE requests SET status=?,ended_at=? WHERE id=?", [
          controller.signal.aborted || runtime.signal.aborted ? "cancelled" : "failed",
          now(),
          requestId
        ]);
        if (!controller.signal.aborted && !runtime.signal.aborted)
          await pause(id, await read(id), "model-request-failed");
      });
      return null;
    } finally {
      if (runtime.request === controller) runtime.request = null;
    }
  }
  async function loop(id, runtime) {
    while (!runtime.signal.aborted) {
      const state = await serial(async () => {
        const value = await read(id);
        if (value.phase === "drawing" && value.deadline <= now())
          await finishRound(id, value, "timeout");
        return value;
      });
      if (["paused", "ended"].includes(state.phase)) return;
      if (state.phase === "preparing" && !state.choices.length) {
        if (state.pool.length < 3) {
          const result = await request(
            id,
            runtime,
            state,
            "words",
            wordPrompt(state.used),
            wordsSchema
          );
          if (!result) continue;
          await serial(async () => {
            const current = await read(id);
            if (current.id !== state.id || current.epoch !== state.epoch) return;
            current.pool = validWords(result.value, current.used);
            if (current.pool.length < 3) {
              await pause(id, current, "word-generation-failed");
              return;
            }
            await write(id, current);
          });
          continue;
        }
        await serial(async () => {
          const current = await read(id);
          if (current.id !== state.id || current.epoch !== state.epoch) return;
          const choices = [];
          for (let i = 0; i < 3; i++)
            choices.push(current.pool.splice(randomInt(current.pool.length), 1)[0]);
          current.choices = choices;
          current.used.push(...choices.map((v) => v.word));
          current.phase = "choosing";
          await write(id, current);
        });
        continue;
      }
      if (state.phase === "choosing" && state.painter === "model") {
        const result = await request(
          id,
          runtime,
          state,
          "choice",
          choicePrompt(state.choices),
          choiceSchema
        );
        if (!result) continue;
        await serial(async () => {
          const current = await read(id);
          if (current.id !== state.id || current.epoch !== state.epoch || current.phase !== "choosing")
            return;
          current.answer = current.choices[result.value.choice - 1];
          current.phase = "ready";
          await write(id, current);
        });
        continue;
      }
      const snapshot = runtime.snapshot;
      const currentImage = snapshot && snapshot.roundId === state.id && snapshot.epoch === state.epoch && snapshot.revision === state.canvasRevision;
      if (state.painter === "human" && state.phase === "drawing" && state.scene.shapes.length && currentImage && state.observed < snapshot.revision && now() - runtime.lastRequest >= 2500) {
        runtime.lastRequest = now();
        const result = await request(
          id,
          runtime,
          state,
          "guess",
          guessPrompt(state.guesses, wordLength(state.answer.word)),
          guessSchema,
          snapshot.image
        );
        if (!result) continue;
        await serial(async () => {
          const current = await read(id);
          if (current.id !== state.id || current.epoch !== state.epoch || current.phase !== "drawing")
            return;
          current.observed = snapshot.revision;
          if (current.deadline <= now()) {
            await finishRound(id, current, "timeout");
            return;
          }
          const guess = result.value.guess.trim();
          if (guess && !current.guesses.some((v) => normalize(v.text) === normalize(guess))) {
            current.guesses.push({ by: "model", text: guess, at: now() });
            if ([current.answer.word, ...current.answer.aliases].some(
              (v) => normalize(v) === normalize(guess)
            )) {
              await finishRound(id, current, "guessed");
              return;
            }
          }
          await write(id, current);
        });
        continue;
      }
      if (state.painter === "model" && ["ready", "drawing"].includes(state.phase) && currentImage && (!state.waiting || state.observedGuesses < state.guesses.length)) {
        const result = await request(
          id,
          runtime,
          state,
          "draw",
          drawPrompt(state),
          drawSchema,
          snapshot.image
        );
        if (!result) continue;
        await serial(async () => {
          const current = await read(id);
          if (current.id !== state.id || current.epoch !== state.epoch || !["ready", "drawing"].includes(current.phase))
            return;
          if (current.phase === "drawing" && current.deadline <= now()) {
            await finishRound(id, current, "timeout");
            return;
          }
          try {
            if (result.value.remove.some(
              (key) => !current.scene.shapes.some((shape) => shape.id === key)
            ))
              throw new Error("missing-shape");
            current.scene = validateCanvas({
              version: 1,
              shapes: [
                ...current.scene.shapes.filter((shape) => !result.value.remove.includes(shape.id)),
                ...result.value.add.map((shape) => ({ ...shape, id: randomUUID() }))
              ]
            });
          } catch {
            current.drawingCorrections++;
            current.drawingError = "\u4E0A\u4E00\u6279\u64CD\u4F5C\u672A\u6267\u884C\uFF1A\u8BF7\u68C0\u67E5\u5750\u6807\u8303\u56F4\u3001\u6210\u5BF9\u7684\u7B14\u753B\u5750\u6807\u548Cremove\u4E2D\u7684\u5DF2\u6709\u5143\u7D20\u6807\u8BC6\u3002\u6309\u5F53\u524D\u753B\u9762\u91CD\u65B0\u63D0\u4EA4\u5408\u6CD5\u64CD\u4F5C\u3002";
            if (current.drawingCorrections >= 2) await pause(id, current, "invalid-drawing");
            else await write(id, current);
            return;
          }
          current.drawingCorrections = 0;
          current.drawingError = null;
          current.canvasRevision++;
          current.waiting = result.value.done || !result.value.add.length && !result.value.remove.length;
          current.observedGuesses = state.guesses.length;
          if (current.phase === "ready") {
            current.phase = "drawing";
            current.deadline = now() + current.remaining;
          }
          await write(id, current);
        });
        continue;
      }
      await wait(runtime);
    }
  }
  return {
    settings: () => serial(settings),
    saveSettings: (input) => serial(async () => {
      const value = settingsValue(input);
      await db.run(
        "INSERT INTO preferences(id,value) VALUES (1,?) ON CONFLICT(id) DO UPDATE SET value=excluded.value",
        [JSON.stringify(value)]
      );
      return value;
    }),
    load: (context) => serial(async () => {
      const id = scope(context), runtime = running.get(id);
      if (runtime) runtime.lastSeen = now();
      return publicState(await read(id));
    }),
    history: (_input, context) => serial(async () => ({ rounds: (await history(scope(context))).map(publicSummary) })),
    async play(_input, context) {
      const id = scope(context);
      if (!context.privateModel?.imageInputSupported)
        return {
          status: "unavailable",
          message: "\u8BF7\u4F7F\u7528\u652F\u6301\u56FE\u7247\u8F93\u5165\u7684\u6A21\u578B\uFF0C\u5E76\u66F4\u65B0\u652F\u6301\u63D2\u4EF6\u63A5\u53E38\u7684LimeA\u3002"
        };
      if (running.has(id)) throw new Error("game-already-running");
      const controller = new AbortController();
      const runtime = {
        signal: AbortSignal.any([context.signal, controller.signal]),
        controller,
        model: context.privateModel,
        runId: context.runId,
        request: null,
        snapshot: null,
        wake: null,
        lastRequest: 0,
        lastSeen: now()
      };
      let settled;
      runtime.done = new Promise((resolve) => {
        settled = resolve;
      });
      running.set(id, runtime);
      let checking = false, lastTick = now();
      const timer = setInterval(() => {
        if (checking || closed) return;
        checking = true;
        void serial(async () => {
          const current = await read(id), time = now(), previousTick = lastTick, slept = time - lastTick > 1e4;
          lastTick = time;
          if (!current || ["paused", "ended"].includes(current.phase)) return;
          if (slept && current.phase !== "result") {
            if (current.deadline) {
              current.remaining = Math.max(0, current.deadline - previousTick);
              current.deadline = null;
            }
            await pause(id, current, "interrupted");
          } else if (time - runtime.lastSeen > 5e3 && current.phase !== "result") {
            await pause(id, current, "viewer-disconnected");
          } else if (current.phase === "drawing" && current.deadline <= time)
            await finishRound(id, current, "timeout");
        }).catch(() => {
          runtime.controller.abort();
        }).finally(() => {
          checking = false;
        });
      }, 500);
      try {
        await serial(async () => {
          let state = await read(id);
          if (!state || state.phase === "ended") {
            const preferences = await settings();
            state = next(
              { pool: [], used: [], duration: preferences.duration },
              preferences.firstPainter
            );
          } else if (state.phase === "paused") {
            state.phase = state.pausedPhase ?? "preparing";
            state.error = null;
            state.pending = null;
            state.drawingCorrections = 0;
            if (state.phase === "drawing") state.deadline = now() + state.remaining;
            state.epoch++;
          }
          if (state.phase === "ready" && state.painter === "human") {
            state.phase = "drawing";
            state.deadline = now() + state.remaining;
          }
          state.runId = context.runId;
          await write(id, state);
        });
        await loop(id, runtime);
        return await serial(async () => ({
          status: (await read(id)).phase,
          rounds: (await history(id)).map(publicSummary)
        }));
      } finally {
        clearInterval(timer);
        controller.abort();
        runtime.request?.abort();
        runtime.wake?.();
        running.delete(id);
        try {
          await serial(async () => {
            const state = await read(id);
            if (state?.runId === context.runId) await pause(id, state, "interrupted");
          });
        } finally {
          settled();
        }
      }
    },
    action: (input) => serial(async () => {
      const id = scope(input), state = await read(id);
      if (!state || input.roundId !== state.id || input.epoch !== state.epoch)
        throw new Error("stale-round");
      if (state.phase === "drawing" && state.deadline <= now())
        await finishRound(id, state, "timeout");
      if (input.action === "quit") {
        state.phase = "ended";
        state.pending = null;
        state.deadline = null;
        state.epoch++;
        await write(id, state);
        cancel(id);
        return publicState(state);
      }
      if (!running.has(id)) throw new Error("game-paused");
      if (input.action === "pause") {
        await pause(id, state, "user");
        return publicState(state);
      }
      if (input.action === "snapshot") {
        if (input.revision !== state.canvasRevision || typeof input.image?.dataUrl !== "string" || input.image.dataUrl.length > 2e6 || input.image.width !== 800 || input.image.height !== 600)
          throw new Error("invalid-snapshot");
        running.get(id).snapshot = {
          roundId: state.id,
          epoch: state.epoch,
          revision: input.revision,
          image: input.image
        };
        running.get(id).wake?.();
        return { accepted: true };
      }
      if (input.action === "choose" && state.phase === "choosing" && state.painter === "human") {
        if (!Number.isInteger(input.choice) || !state.choices[input.choice])
          throw new Error("invalid-choice");
        state.answer = state.choices[input.choice];
        state.phase = "drawing";
        state.deadline = now() + state.remaining;
      } else if (input.action === "draw" && state.phase === "drawing" && state.painter === "human") {
        if (input.revision !== state.canvasRevision) throw new Error("stale-canvas");
        state.scene = validateCanvas(input.scene);
        state.canvasRevision++;
      } else if (input.action === "guess" && state.phase === "drawing" && state.painter === "model") {
        const text2 = String(input.text ?? "").trim();
        if (!text2 || text2.length > 40 || state.guesses.length >= 100)
          throw new Error("invalid-guess");
        state.guesses.push({ by: "human", text: text2, at: now() });
        if ([state.answer.word, ...state.answer.aliases].some(
          (value) => normalize(value) === normalize(text2)
        )) {
          await finishRound(id, state, "guessed");
          return publicState(state);
        }
      } else if (input.action === "reveal" && ["drawing", "ready"].includes(state.phase)) {
        await finishRound(id, state, "revealed");
        return publicState(state);
      } else if (input.action === "next" && state.phase === "result") {
        const value = next(state, state.painter === "human" ? "model" : "human");
        await write(id, value);
        return publicState(value);
      } else throw new Error("invalid-action");
      await write(id, state);
      return publicState(state);
    }),
    finished: (context) => serial(async () => {
      const id = scope(context), state = await read(id);
      if (state?.runId === context.runId) await pause(id, state, "interrupted");
    }),
    async dispose() {
      const active = [...running.values()];
      for (const runtime of active) {
        runtime.controller.abort();
        runtime.request?.abort();
        runtime.wake?.();
      }
      await Promise.all(active.map((runtime) => runtime.done));
      await queue;
      closed = true;
    }
  };
}

// src/backend.mjs
async function apply(context) {
  if (!context.canvas) throw new Error("draw-guess-host-update-required");
  const database = await context.storage.openDatabase({ name: "game", migrations });
  const game = await createGame(database, { validateCanvas: context.canvas.validate });
  context.commands.register("load-game", (input) => input?.sessionId ? game.load(input) : null);
  context.commands.register("game-action", game.action);
  context.commands.register("load-settings", game.settings);
  context.commands.register("save-settings", game.saveSettings);
  context.tools.register("play", game.play);
  context.tools.register("history", game.history);
  context.tools.interaction({ policy: async () => null, finished: game.finished });
  context.onDispose(async () => {
    await game.dispose();
    await database.close();
  });
}
export {
  apply
};
