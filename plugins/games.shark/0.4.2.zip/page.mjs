// src/page.css
var page_default = ":host {\n  color: var(--foreground);\n  font-family: inherit;\n}\n* {\n  box-sizing: border-box;\n}\n[hidden] {\n  display: none !important;\n}\nh2 {\n  display: flex;\n  align-items: center;\n  gap: var(--ui-space-2);\n  font-size: var(--ui-text-base);\n  font-weight: 600;\n  margin: 0;\n  padding-bottom: var(--ui-space-3);\n  border-bottom: 1px solid var(--border);\n}\nh3 {\n  font-size: var(--ui-text-sm);\n  font-weight: 600;\n  margin: 0 0 var(--ui-space-1);\n}\np {\n  margin: 0;\n  font-size: var(--ui-text-sm);\n  line-height: var(--ui-leading-prose);\n  overflow-wrap: anywhere;\n}\n.intro {\n  margin-bottom: var(--ui-space-8);\n}\n.intro ul {\n  display: grid;\n  gap: var(--ui-space-2);\n  margin: 0;\n  padding: 0;\n  list-style: none;\n}\n.intro li {\n  position: relative;\n  padding-left: var(--ui-space-4);\n  color: var(--muted-foreground);\n  font-size: var(--ui-text-sm);\n  line-height: var(--ui-leading-prose);\n  overflow-wrap: anywhere;\n}\n.intro li::before {\n  content: '';\n  position: absolute;\n  top: 0.7em;\n  left: 0;\n  width: 0.25rem;\n  height: 0.25rem;\n  border-radius: 50%;\n  background: currentColor;\n}\n.intro strong {\n  color: var(--foreground);\n  font-weight: 600;\n}\n.section-icon,\n.feature-icon,\n.section-count {\n  color: var(--muted-foreground);\n}\n.section-icon,\n.feature-icon {\n  display: inline-flex;\n  flex: none;\n}\n.section-count {\n  font-size: var(--ui-text-sm);\n  font-weight: 400;\n}\n.features,\n.usage {\n  margin-top: var(--ui-space-8);\n}\n.features ul {\n  margin: 0;\n  padding: 0;\n  list-style: none;\n}\n.features li {\n  display: flex;\n  align-items: flex-start;\n  gap: var(--ui-space-4);\n  padding: var(--ui-space-5) 0 0;\n}\n.feature-icon {\n  width: 2.25rem;\n  min-height: 2.25rem;\n  align-items: center;\n  justify-content: center;\n}\n.features p {\n  color: var(--muted-foreground);\n}\n.usage p {\n  margin-top: var(--ui-space-4);\n  text-wrap: pretty;\n}\n.usage blockquote {\n  margin: var(--ui-space-3) 0 0;\n  padding: var(--ui-space-2) 0 var(--ui-space-2) var(--ui-space-4);\n  border-left: 2px solid var(--border);\n  font-size: var(--ui-text-sm);\n  line-height: var(--ui-leading-prose);\n  text-wrap: pretty;\n}\n";

// src/page-strings.mjs
var zh = {
  introLabel: "\u9CA8\u9C7C\u54AC\u7259\u80FD\u600E\u4E48\u73A9",
  introFirstTitle: "\u968F\u673A\u5148\u624B\uFF1A",
  introFirstDetail: "\u6BCF\u5C40\u7531\u63D2\u4EF6\u968F\u673A\u51B3\u5B9A\u8C01\u5148\u6309\uFF0C\u51CF\u5C11\u56FA\u5B9A\u987A\u5E8F\u3002",
  introTurnsTitle: "\u8F6E\u6D41\u6309\u7259\uFF1A",
  introTurnsDetail: "\u4F60\u548C\u89D2\u8272\u4EA4\u66FF\u9009\u62E9\u7259\u9F7F\uFF0C\u70B9 3D \u6A21\u578B\u6216\u5E95\u90E8\u7F16\u53F7\u90FD\u53EF\u4EE5\u3002",
  introTrapTitle: "\u5C0F\u5FC3\u574F\u7259\uFF1A",
  introTrapDetail: "\u6BCF\u5C40\u56FA\u5B9A\u4E00\u9897\u574F\u7259\uFF0C\u6309\u4E2D\u5C31\u4F1A\u5408\u5634\u7ED3\u675F\u3002",
  introReplayTitle: "\u7ED3\u675F\u518D\u73A9\uFF1A",
  introReplayDetail: "\u7ED3\u7B97\u6BD4\u5206\u540E\u53EF\u518D\u6765\u4E00\u5C40\uFF0C\u6216\u4E0B\u6B21\u518D\u73A9\u3002",
  featuresTitle: "\u63D2\u4EF6\u529F\u80FD",
  startTitle: "\u5F00\u5C40\u4E0E\u5148\u624B",
  startDetail: "\u652F\u6301\u5355\u4EBA\u548C\u89D2\u8272\u966A\u73A9\uFF1B\u6BCF\u5C40 12 \u9897\u7259\u30011 \u9897\u574F\u7259\uFF0C\u5F00\u5C40\u968F\u673A\u5148\u624B\u3002",
  turnsTitle: "\u8F6E\u6D41\u6309\u7259",
  turnsDetail: "\u7528\u6237\u548C\u89D2\u8272\u4EA4\u66FF\uFF1B\u7528\u6237\u56DE\u5408\u7B49\u5F85\uFF0C\u4E0D\u8BF7\u6C42\u6A21\u578B\uFF1B\u89D2\u8272\u56DE\u5408\u901A\u8FC7\u5DE5\u5177\u9009\u62E9\uFF0C\u4FDD\u5B58\u6210\u529F\u540E\u624D\u64AD\u653E\u52A8\u4F5C\u3002",
  modelTitle: "3D \u9CA8\u9C7C",
  modelDetail: "Three.js \u6A21\u578B\u968F\u804A\u5929\u6253\u5F00\uFF1B\u53EF\u70B9\u7259\u9F7F\u6216\u5E95\u90E8\u7F16\u53F7\uFF0C\u6309\u7259\u548C\u5408\u5634\u90FD\u6709\u52A8\u753B\u4E0E\u97F3\u6548\u3002",
  companionTitle: "\u89D2\u8272\u966A\u73A9",
  companionDetail: "\u6CBF\u7528\u5F53\u524D\u4F1A\u8BDD\u7684\u89D2\u8272\u5361\u59D3\u540D\u548C\u6A21\u578B\uFF1B\u5371\u9669\u7259\u53EA\u5728\u63D2\u4EF6\u5E93\u4FDD\u5B58\uFF0C\u6A21\u578B\u53EA\u6536\u5230\u5DF2\u6309\u548C\u5269\u4F59\u7259\u9F7F\u3002",
  scoreTitle: "\u6BD4\u5206\u4E0E\u6682\u505C",
  scoreDetail: "\u6BCF\u5C40\u7D2F\u8BA1\u6BD4\u5206\uFF1B\u5168\u5C40\u505C\u6B62\u3001\u5931\u8D25\u6216\u91CD\u542F\u4F1A\u6682\u505C\u5E76\u4FDD\u7559\u5371\u9669\u7259\u3001\u843D\u5B50\u4E0E\u6BD4\u5206\uFF0C\u7EE7\u7EED\u966A\u73A9\u5373\u53EF\u6062\u590D\u3002",
  storageTitle: "\u672C\u5730\u5B58\u6863",
  storageDetail: "\u5BF9\u5C40\u5199\u5165\u63D2\u4EF6\u6570\u636E\u76EE\u5F55\uFF1B\u4F1A\u8BDD\u548C\u8349\u7A3F\u5206\u5F00\u4FDD\u5B58\uFF0C\u5207\u6362\u4F1A\u8BDD\u4E0D\u4F1A\u7EE7\u627F\u53E6\u4E00\u4F1A\u8BDD\u7684\u5BF9\u5C40\uFF0C\u4E5F\u4E0D\u9700\u8981\u8054\u7F51\u3002",
  usageTitle: "\u5F00\u59CB\u4F7F\u7528",
  usage: "\u4ECE\u804A\u5929\u53F3\u4FA7\u6253\u5F00\u300C\u5C0F\u6E38\u620F\u300D\uFF0C\u9009\u4E2D\u300C\u9CA8\u9C7C\u54AC\u7259\u300D\uFF1B\u4E5F\u53EF\u4EE5\u76F4\u63A5\u8BA9\u89D2\u8272\u966A\u4F60\u73A9\u3002\u4F60\u53EF\u4EE5\u8FD9\u6837\u8BF4\uFF1A",
  usageExample: "\u966A\u6211\u73A9\u4E00\u5C40\u9CA8\u9C7C\u54AC\u7259\u5427\uFF0C\u4F60\u5148\u6309\u3002"
};
var en = {
  introLabel: "How Shark Teeth works",
  introFirstTitle: "Random first player:",
  introFirstDetail: "The plugin randomly decides who presses first each round.",
  introTurnsTitle: "Take turns:",
  introTurnsDetail: "You and the character alternate; tap the 3D model or the numbered buttons at the bottom.",
  introTrapTitle: "Mind the bad tooth:",
  introTrapDetail: "One tooth is the bad tooth each round; press it and the jaw snaps shut.",
  introReplayTitle: "Play again:",
  introReplayDetail: "After the score is counted, start another round or stop.",
  featuresTitle: "Plugin features",
  startTitle: "Rounds and first player",
  startDetail: "Solo and companion play; 12 teeth with 1 bad tooth, and a random first player each round.",
  turnsTitle: "Alternating presses",
  turnsDetail: "You and the character alternate; your turn waits without model requests; the character picks through tools and the move plays only after it is saved.",
  modelTitle: "3D shark",
  modelDetail: "A Three.js model opens beside the chat; tap teeth or numbered buttons, with press and snap animations and sound.",
  companionTitle: "Companion play",
  companionDetail: "Uses the current conversation\u2019s character name and model; the bad tooth stays in the plugin database, and the model only sees pressed and remaining teeth.",
  scoreTitle: "Score and pause",
  scoreDetail: "Scores accumulate across rounds; stopping, failure or restart pauses the game and keeps the bad tooth, presses and score; continue to resume.",
  storageTitle: "Local saves",
  storageDetail: "Rounds are stored in the plugin data directory; conversations and drafts are kept separate, and the game works without a network.",
  usageTitle: "Start playing",
  usage: "Open Mini games from the right side of the chat and choose Shark Teeth, or ask the character to play. Try saying:",
  usageExample: "Let\u2019s play Shark Teeth. You press first."
};

// src/page.mjs
function mount(container, context) {
  if (!context.controls) throw new Error("plugin-host-upgrade-required");
  const t = context.language.startsWith("zh") ? zh : en;
  const style = document.createElement("style");
  style.textContent = page_default;
  const root = document.createElement("div");
  root.className = "shark-page";
  root.innerHTML = `
    <section class="intro" aria-label="">
      <ul></ul>
    </section>
    <section class="features" aria-labelledby="shark-features-title">
      <h2 id="shark-features-title"><span class="section-icon" data-icon="blocks"></span><span class="heading-label"></span><span class="section-count"></span></h2>
      <ul></ul>
    </section>
    <section class="usage" aria-labelledby="shark-usage-title">
      <h2 id="shark-usage-title"><span class="section-icon" data-icon="message-square"></span><span class="heading-label"></span></h2>
      <p></p>
      <blockquote></blockquote>
    </section>`;
  container.replaceChildren(style, root);
  const query = (selector) => root.querySelector(selector);
  query(".intro").setAttribute("aria-label", t.introLabel);
  const introItems = [
    [t.introFirstTitle, t.introFirstDetail],
    [t.introTurnsTitle, t.introTurnsDetail],
    [t.introTrapTitle, t.introTrapDetail],
    [t.introReplayTitle, t.introReplayDetail]
  ];
  const introList = query(".intro ul");
  for (const [title, detail] of introItems) {
    const item = document.createElement("li");
    const heading = document.createElement("strong");
    heading.textContent = title;
    const copy = document.createElement("span");
    copy.textContent = detail;
    item.append(heading, copy);
    introList.append(item);
  }
  const features = [
    { icon: "circle-dashed", title: t.startTitle, detail: t.startDetail },
    { icon: "refresh-cw", title: t.turnsTitle, detail: t.turnsDetail },
    { icon: "blocks", title: t.modelTitle, detail: t.modelDetail },
    { icon: "message-square", title: t.companionTitle, detail: t.companionDetail },
    { icon: "circle-check", title: t.scoreTitle, detail: t.scoreDetail },
    { icon: "shield-check", title: t.storageTitle, detail: t.storageDetail }
  ];
  const featureList = query(".features ul");
  for (const feature of features) {
    const item = document.createElement("li");
    const iconSlot = document.createElement("span");
    iconSlot.className = "feature-icon";
    iconSlot.dataset.icon = feature.icon;
    const copy = document.createElement("div");
    const heading = document.createElement("h3");
    heading.textContent = feature.title;
    const detail = document.createElement("p");
    detail.textContent = feature.detail;
    copy.append(heading, detail);
    item.append(iconSlot, copy);
    featureList.append(item);
  }
  query(".features h2 .heading-label").textContent = t.featuresTitle;
  query(".features h2 .section-count").textContent = String(features.length);
  query(".usage h2 .heading-label").textContent = t.usageTitle;
  query(".usage p").textContent = t.usage;
  query(".usage blockquote").textContent = t.usageExample;
  const handles = [];
  for (const slot of root.querySelectorAll("[data-icon]")) {
    const name = slot.dataset.icon;
    if (context.controls.icons?.includes(name))
      handles.push(context.controls.mount(slot, { type: "icon", name, size: 18 }));
    else slot.hidden = true;
  }
  function cleanup() {
    for (const handle of handles) handle.destroy();
    container.replaceChildren();
  }
  context.signal.addEventListener("abort", cleanup, { once: true });
  return cleanup;
}
export {
  mount
};
