// src/duo.mjs
import { randomInt, randomUUID } from "node:crypto";
var duoMigration = {
  id: "1001_companion_matches",
  sql: "CREATE TABLE companion_matches (session_id TEXT PRIMARY KEY, state TEXT NOT NULL CHECK(json_valid(state)));"
};
var teeth = Array.from({ length: 12 }, (_, i) => i + 1);
function publicMatch(match) {
  if (!match) return null;
  const { trap: _trap, operations: _operations, ...view } = match;
  return {
    ...view,
    remaining: teeth.filter((tooth) => !match.pressed.some((move) => move.tooth === tooth))
  };
}
async function createCompanionGame(database, { draw = () => randomInt(1, 13), first = () => randomInt(2) === 0 ? "human" : "model" } = {}) {
  let queue = Promise.resolve();
  let closed = false;
  const waiters = /* @__PURE__ */ new Map();
  const serial = (work) => {
    if (closed) return Promise.reject(new Error("game-closed"));
    const next = queue.then(work);
    queue = next.catch(() => {
    });
    return next;
  };
  const key = (context) => {
    if (context?.mode !== "chat" || typeof context.sessionId !== "string" || !context.sessionId || context.sessionId.length > 128)
      throw new Error("invalid-game-scope");
    return context.sessionId;
  };
  const read = async (id) => {
    const row = await database.get("SELECT state FROM companion_matches WHERE session_id = ?", [
      id
    ]);
    return row ? JSON.parse(row.state) : null;
  };
  const notify = (id) => {
    for (const wake of waiters.get(id) ?? []) wake();
  };
  const write = async (id, match) => {
    match.revision++;
    await database.run(
      "INSERT INTO companion_matches(session_id,state) VALUES (?,?) ON CONFLICT(session_id) DO UPDATE SET state=excluded.state",
      [id, JSON.stringify(match)]
    );
    notify(id);
    return publicMatch(match);
  };
  const round = (match) => {
    match.roundId = randomUUID();
    match.roundNumber++;
    match.trap = draw();
    match.pressed = [];
    match.first = first();
    match.turn = match.first;
    match.status = "active";
    match.winner = null;
    match.reason = null;
  };
  const press = (match, player, tooth) => {
    if (match.status !== "active" || match.turn !== player) throw new Error("not-your-turn");
    if (!Number.isInteger(tooth) || !teeth.includes(tooth) || match.pressed.some((move) => move.tooth === tooth))
      throw new Error("invalid-tooth");
    match.pressed.push({ tooth, player });
    if (match.trap === tooth) {
      match.status = "round-over";
      match.winner = player === "human" ? "model" : "human";
      match.scores[match.winner]++;
      match.turn = null;
    } else match.turn = player === "human" ? "model" : "human";
  };
  const assertRun = (match, context) => {
    if (!match || match.runId !== context.runId) throw new Error("stale-game-run");
  };
  const wait = async (context) => {
    const id = key(context);
    while (true) {
      context.signal.throwIfAborted();
      let cleanup;
      let wake;
      const changed = new Promise((resolve) => {
        wake = resolve;
      });
      if (!waiters.has(id)) waiters.set(id, /* @__PURE__ */ new Set());
      waiters.get(id).add(wake);
      const aborted = () => wake();
      context.signal.addEventListener("abort", aborted, { once: true });
      cleanup = () => {
        context.signal.removeEventListener("abort", aborted);
        waiters.get(id)?.delete(wake);
        if (!waiters.get(id)?.size) waiters.delete(id);
      };
      try {
        const match = await serial(() => read(id));
        assertRun(match, context);
        if (match.status === "ended" || match.status === "round-over" || match.status === "active" && match.turn === "model")
          return publicMatch(match);
        if (match.status === "paused") throw new Error("game-paused");
        await changed;
      } finally {
        cleanup();
      }
    }
  };
  for (const row of await database.all("SELECT session_id,state FROM companion_matches")) {
    const match = JSON.parse(row.state);
    if (!["paused", "ended"].includes(match.status)) {
      match.pausedPhase = match.status;
      match.status = "paused";
      match.reason = "interrupted";
      await write(row.session_id, match);
    }
  }
  return {
    async load(context) {
      return serial(async () => publicMatch(await read(key(context))));
    },
    async start(_input, context) {
      const id = key(context);
      context.signal.throwIfAborted();
      await serial(async () => {
        context.signal.throwIfAborted();
        let match = await read(id);
        if (match && !["paused", "ended"].includes(match.status) && match.runId !== context.runId)
          throw new Error("game-already-running");
        if (match?.runId === context.runId && match.operations.includes(context.executionId))
          return;
        if (!match || match.status === "ended") {
          match = {
            matchId: randomUUID(),
            roundId: "",
            roundNumber: 0,
            revision: 0,
            runId: context.runId,
            scores: { human: 0, model: 0 },
            operations: []
          };
          round(match);
        } else if (match.status === "paused") {
          match.runId = context.runId;
          match.status = match.pausedPhase;
          match.reason = null;
          match.operations = [];
        } else if (match.status === "round-over") match.status = "waiting-replay";
        else if (match.status !== "waiting-replay") throw new Error("game-already-running");
        match.operations.push(context.executionId);
        await write(id, match);
      });
      return wait(context);
    },
    async modelPress(input, context) {
      const id = key(context);
      context.signal.throwIfAborted();
      await serial(async () => {
        context.signal.throwIfAborted();
        const match = await read(id);
        assertRun(match, context);
        if (match.status === "ended" || match.operations.includes(context.executionId)) return;
        if (input.roundId !== match.roundId || input.revision !== match.revision)
          throw new Error("stale-round");
        press(match, "model", input.tooth);
        match.operations.push(context.executionId);
        await write(id, match);
      });
      return wait(context);
    },
    async act(payload) {
      return serial(async () => {
        const id = key(payload), match = await read(id);
        if (!match || payload.matchId !== match.matchId || payload.roundId !== match.roundId || payload.revision !== match.revision)
          throw new Error("stale-round");
        if (payload.action === "quit") {
          match.status = "ended";
          match.turn = null;
          match.reason = "user-ended";
        } else if (payload.action === "replay") {
          if (match.status !== "waiting-replay") throw new Error("not-waiting-for-replay");
          round(match);
        } else if (payload.action === "press") press(match, "human", payload.tooth);
        else throw new Error("invalid-game-action");
        return write(id, match);
      });
    },
    async policy(context) {
      return serial(async () => {
        const match = await read(key(context));
        if (!match || match.runId !== context.runId || match.status === "paused") return null;
        const state = JSON.stringify(publicMatch(match));
        if (match.status === "ended")
          return {
            revision: String(match.revision),
            required: false,
            toolIds: [],
            instruction: `\u7528\u6237\u624B\u52A8\u9009\u62E9\u4E86\u7ED3\u675F\u6E38\u620F\u3002\u6BD4\u5206\u548C\u72B6\u6001\uFF1A${state}\u3002\u7B80\u77ED\u56DE\u5E94\u540E\u7ED3\u675F\u672C\u8F6E\uFF0C\u4E0D\u8981\u91CD\u65B0\u5F00\u5C40\u3002`
          };
        if (match.status === "round-over")
          return {
            revision: String(match.revision),
            required: true,
            toolIds: ["start"],
            instruction: `\u672C\u5C40\u5DF2\u7ED3\u675F\uFF0C\u7ED3\u679C\uFF1A${state}\u3002\u5148\u7528\u4E00\u53E5\u8BDD\u56DE\u5E94\u8F93\u8D62\uFF0C\u7136\u540E\u8C03\u7528 start \u5DE5\u5177\u7B49\u5F85\u7528\u6237\u9009\u62E9\u201C\u518D\u6765\u4E00\u5C40/\u4E0B\u6B21\u518D\u73A9\u201D\u3002\u4E0D\u53EF\u66FF\u7528\u6237\u51B3\u5B9A\u3002`
          };
        if (match.status === "active" && match.turn === "model")
          return {
            revision: String(match.revision),
            required: true,
            toolIds: ["press_tooth"],
            instruction: `\u8F6E\u5230\u4F60\u9009\u7259\u9F7F\u3002\u6E38\u620F\u72B6\u6001\uFF1A${state}\u3002\u8C03\u7528 press_tooth\uFF0C\u4F20\u5165\u5F53\u524D roundId\u3001revision \u548C\u4E00\u4E2A remaining \u4E2D\u7684\u7F16\u53F7\u3002\u53EA\u9009\u4E00\u9897\uFF0C\u4E0D\u5F97\u63A8\u65AD\u5371\u9669\u7259\u9F7F\u3002`
          };
        throw new Error("game-wait-not-owned");
      });
    },
    async finished(context) {
      return serial(async () => {
        const id = key(context), match = await read(id);
        if (match?.runId === context.runId && !["ended", "paused"].includes(match.status)) {
          match.pausedPhase = match.status;
          match.status = "paused";
          match.reason = "interrupted";
          await write(id, match);
        }
      });
    },
    async dispose() {
      closed = true;
      for (const id of waiters.keys()) notify(id);
      await queue;
    }
  };
}

// src/backend.mjs
import { randomInt as randomInt2, randomUUID as randomUUID2 } from "node:crypto";
var TEETH = 12;
function scopeKey(payload) {
  if (!payload || payload.mode !== "chat" || payload.sessionId !== null && (typeof payload.sessionId !== "string" || payload.sessionId.length > 128))
    throw new Error("invalid-game-scope");
  return JSON.stringify([payload.mode, payload.sessionId]);
}
function publicRound(round) {
  return { id: round.id, pressed: round.pressed, status: round.status, teeth: TEETH };
}
var migrations = [
  {
    id: "1000_initial",
    sql: "CREATE TABLE IF NOT EXISTS rounds (scope TEXT PRIMARY KEY, state TEXT NOT NULL);"
  },
  duoMigration
];
async function createGameStore(storage, draw = () => randomInt2(1, TEETH + 1)) {
  const database = await storage.openDatabase({
    name: "rounds",
    migrations,
    legacyFile: "rounds.sqlite"
  });
  let queue = Promise.resolve();
  let disposed = false;
  const serial = (action) => {
    if (disposed) return Promise.reject(new Error("game-closed"));
    const result = queue.then(action);
    queue = result.catch(() => {
    });
    return result;
  };
  const read = async (key) => {
    const row = await database.get("SELECT state FROM rounds WHERE scope = ?", [key]);
    return row ? JSON.parse(row.state) : null;
  };
  const make = () => ({ id: randomUUID2(), trap: draw(), pressed: [], status: "playing" });
  const write = async (key, round) => {
    await database.run(
      "INSERT INTO rounds(scope, state) VALUES (?, ?) ON CONFLICT(scope) DO UPDATE SET state=excluded.state",
      [key, JSON.stringify(round)]
    );
    return publicRound(round);
  };
  return {
    database,
    load: (payload) => serial(async () => {
      const key = scopeKey(payload), round = await read(key);
      return round ? publicRound(round) : write(key, make());
    }),
    press: (payload) => serial(async () => {
      const key = scopeKey(payload), round = await read(key);
      if (!Number.isInteger(payload.tooth) || payload.tooth < 1 || payload.tooth > TEETH)
        throw new Error("invalid-tooth");
      if (!round || round.id !== payload.roundId) throw new Error("stale-round");
      if (round.status === "bitten" || round.pressed.includes(payload.tooth))
        return publicRound(round);
      round.pressed.push(payload.tooth);
      if (round.trap === payload.tooth) round.status = "bitten";
      return write(key, round);
    }),
    restart: (payload) => serial(async () => {
      const key = scopeKey(payload), round = await read(key);
      if (round && round.id !== payload.roundId) throw new Error("stale-round");
      return write(key, make());
    }),
    async dispose() {
      disposed = true;
      await queue;
      await database.close();
    }
  };
}
async function apply(context) {
  const game = await createGameStore(context.storage);
  const companion = await createCompanionGame(game.database);
  context.onDispose(async () => {
    await companion.dispose();
    await game.dispose();
  });
  const solo = (action) => async (payload) => {
    if (payload?.sessionId && await context.sessions.isRunning(payload.sessionId))
      throw new Error("session-busy");
    const match = payload?.sessionId ? await companion.load(payload) : null;
    if (match && !["ended", "paused"].includes(match.status))
      throw new Error("game-already-running");
    return action(payload);
  };
  context.commands.register("load-round", (payload) => game.load(payload));
  context.commands.register("press-tooth", solo(game.press));
  context.commands.register("new-round", solo(game.restart));
  context.commands.register(
    "load-match",
    (payload) => payload?.sessionId ? companion.load(payload) : null
  );
  context.commands.register("match-action", async (payload) => {
    if (payload.action !== "quit" && !await context.sessions.isRunning(payload.sessionId))
      throw new Error("game-paused");
    return companion.act(payload);
  });
  context.tools.register("start", companion.start);
  context.tools.register("press_tooth", companion.modelPress);
  context.tools.interaction({ policy: companion.policy, finished: companion.finished });
}
export {
  apply,
  createGameStore,
  migrations
};
