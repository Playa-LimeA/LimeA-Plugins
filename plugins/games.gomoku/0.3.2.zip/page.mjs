// src/page.css
var page_default = ":host {\n  color: var(--foreground);\n  font-family: inherit;\n}\n* {\n  box-sizing: border-box;\n}\n[hidden] {\n  display: none !important;\n}\nh2 {\n  display: flex;\n  align-items: center;\n  gap: var(--ui-space-2);\n  font-size: var(--ui-text-base);\n  font-weight: 600;\n  margin: 0;\n  padding-bottom: var(--ui-space-3);\n  border-bottom: 1px solid var(--border);\n}\nh3 {\n  font-size: var(--ui-text-sm);\n  font-weight: 600;\n  margin: 0 0 var(--ui-space-1);\n}\np {\n  margin: 0;\n  font-size: var(--ui-text-sm);\n  line-height: var(--ui-leading-prose);\n  overflow-wrap: anywhere;\n}\n.intro {\n  margin-bottom: var(--ui-space-8);\n}\n.intro ul {\n  display: grid;\n  gap: var(--ui-space-2);\n  margin: 0;\n  padding: 0;\n  list-style: none;\n}\n.intro li {\n  position: relative;\n  padding-left: var(--ui-space-4);\n  color: var(--muted-foreground);\n  font-size: var(--ui-text-sm);\n  line-height: var(--ui-leading-prose);\n  overflow-wrap: anywhere;\n}\n.intro li::before {\n  content: '';\n  position: absolute;\n  top: 0.7em;\n  left: 0;\n  width: 0.25rem;\n  height: 0.25rem;\n  border-radius: 50%;\n  background: currentColor;\n}\n.intro strong {\n  color: var(--foreground);\n  font-weight: 600;\n}\n.section-icon,\n.feature-icon,\n.section-count {\n  color: var(--muted-foreground);\n}\n.section-icon,\n.feature-icon {\n  display: inline-flex;\n  flex: none;\n}\n.section-count {\n  font-size: var(--ui-text-sm);\n  font-weight: 400;\n}\n.features,\n.settings,\n.usage {\n  margin-top: var(--ui-space-8);\n}\n.features ul {\n  margin: 0;\n  padding: 0;\n  list-style: none;\n}\n.features li {\n  display: flex;\n  align-items: flex-start;\n  gap: var(--ui-space-4);\n  padding: var(--ui-space-5) 0 0;\n}\n.feature-icon {\n  width: 2.25rem;\n  min-height: 2.25rem;\n  align-items: center;\n  justify-content: center;\n}\n.features p {\n  color: var(--muted-foreground);\n}\n.usage p {\n  margin-top: var(--ui-space-4);\n  text-wrap: pretty;\n}\n.usage blockquote {\n  margin: var(--ui-space-3) 0 0;\n  padding: var(--ui-space-2) 0 var(--ui-space-2) var(--ui-space-4);\n  border-left: 2px solid var(--border);\n  font-size: var(--ui-text-sm);\n  line-height: var(--ui-leading-prose);\n  text-wrap: pretty;\n}\n";

// src/settings.css
var settings_default = ".gomoku-settings {\n  --ink: var(--foreground, #ededed);\n  --soft: var(--muted-foreground, #b5b5b5);\n  --line: var(--border, #353535);\n  --green: var(--primary, #adeb78);\n  color: var(--ink);\n  font: inherit;\n}\n.gomoku-settings * {\n  box-sizing: border-box;\n}\n.gomoku-settings [hidden] {\n  display: none !important;\n}\n.gomoku-settings .settings-intro {\n  margin: 8px 0 24px;\n  color: var(--soft);\n  font-size: 13px;\n}\n.gomoku-settings fieldset {\n  border: 0;\n  margin: 0 0 20px;\n  padding: 0;\n  min-width: 0;\n}\n.gomoku-settings legend {\n  margin-bottom: 12px;\n  font-size: 13px;\n  font-weight: 600;\n}\n.gomoku-settings label {\n  display: flex;\n  align-items: flex-start;\n  gap: 10px;\n  padding: 12px 0;\n  cursor: pointer;\n}\n.gomoku-settings label + label {\n  border-top: 1px solid var(--line);\n}\n.gomoku-settings input {\n  accent-color: var(--green);\n  margin: 3px 0 0;\n  flex: none;\n}\n.gomoku-settings input:focus-visible,\n.gomoku-settings button:focus-visible {\n  outline: 2px solid var(--green);\n  outline-offset: 3px;\n}\n.gomoku-settings strong {\n  font-size: 14px;\n  font-weight: 500;\n}\n.gomoku-settings small {\n  display: block;\n  font-size: 12px;\n  line-height: 1.6;\n  margin-top: 5px;\n  color: var(--soft);\n}\n.gomoku-settings .difficulty-options > div {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 0 24px;\n}\n.gomoku-settings .difficulty-options label + label {\n  border: 0;\n}\n.gomoku-settings .settings-feedback {\n  margin: 0 0 12px;\n  min-height: 20px;\n  color: var(--soft);\n  font-size: 12px;\n}\n.gomoku-settings .settings-feedback[role='alert'] {\n  color: var(--destructive, #ff9284);\n}\n.gomoku-settings .settings-note {\n  margin-top: 12px;\n}\n.gomoku-settings button {\n  font: inherit;\n  cursor: pointer;\n  color: var(--ink);\n  background: transparent;\n  border: 1px solid var(--line);\n  border-radius: 8px;\n  padding: 8px 12px;\n}\n.gomoku-settings button:hover {\n  background: var(--muted, #282828);\n}\n";

// src/settings.mjs
function mount(container, context) {
  const tr = (zh2, en2) => context.language.startsWith("en") ? en2 : zh2;
  const root = document.createElement("section");
  root.className = "gomoku-settings";
  const style = document.createElement("style");
  style.textContent = settings_default;
  root.innerHTML = `<p class="settings-intro">${tr("\u9009\u62E9\u89D2\u8272\u5982\u4F55\u601D\u8003\u4E0B\u4E00\u6B65\u3002", "Choose how your character considers its next move.")}</p>
    <form><fieldset class="mode-options"><legend>${tr("\u843D\u5B50\u65B9\u5F0F", "Move selection")}</legend>
    <label><input type="radio" name="mode" value="model"><span><strong>${tr("\u6A21\u578B\u843D\u5B50", "Model only")}</strong><small>${tr("\u89D2\u8272\u81EA\u5DF1\u8BFB\u68CB\u76D8\u3001\u60F3\u7B56\u7565\uFF0C\u68CB\u529B\u53D6\u51B3\u4E8E\u5F53\u524D\u6A21\u578B\u3002", "Your character reads the board and chooses its own strategy.")}</small></span></label>
    <label><input type="radio" name="mode" value="engine"><span><strong>${tr("\u5F15\u64CE\u8F85\u52A9", "Engine assisted")}</strong><small>${tr("\u8BA1\u7B97\u4E09\u4E2A\u5019\u9009\u843D\u70B9\u53CA\u8BC4\u5206\uFF0C\u7531\u89D2\u8272\u51B3\u5B9A\u6700\u7EC8\u843D\u5B50\u3002", "Calculate up to three scored candidates. Your character makes the final choice.")}</small></span></label></fieldset>
    <fieldset class="difficulty-options" hidden><legend>${tr("\u5206\u6790\u96BE\u5EA6", "Analysis level")}</legend><div>
    <label><input type="radio" name="difficulty" value="normal"><span><strong>${tr("\u666E\u901A", "Normal")}</strong><small>${tr("\u8F83\u5FEB\u5206\u6790\uFF0C\u8F7B\u677E\u966A\u73A9", "Quick analysis, casual play")}</small></span></label>
    <label><input type="radio" name="difficulty" value="hard"><span><strong>${tr("\u56F0\u96BE", "Hard")}</strong><small>${tr("\u591A\u60F3\u51E0\u6B65\uFF0C\u5BFB\u627E\u653B\u9632\u673A\u4F1A", "Deeper search for threats")}</small></span></label></div></fieldset>
    <p class="settings-feedback" role="status"></p><button class="retry-settings" type="button" hidden>${tr("\u91CD\u65B0\u8BFB\u53D6", "Reload settings")}</button>
    <small class="settings-note">${tr("\u81EA\u52A8\u4FDD\u5B58\uFF0C\u4ECE\u4E0B\u4E00\u5C40\u751F\u6548\u3002\u6240\u6709\u804A\u5929\u5171\u7528\u6B64\u8BBE\u7F6E\u3002", "Saved automatically. Applies next round, across chats.")}</small></form>`;
  root.prepend(style);
  container.append(root);
  const form = root.querySelector("form"), feedback = root.querySelector(".settings-feedback"), retry = root.querySelector(".retry-settings");
  const events = new AbortController();
  let disposed = false, ready = false, busy = false;
  const disable = () => {
    for (const input of form.querySelectorAll("input")) input.disabled = !ready || busy;
  };
  const show = (settings) => {
    for (const input of form.querySelectorAll("input"))
      input.checked = settings[input.name] === input.value;
    root.querySelector(".difficulty-options").hidden = settings.mode !== "engine";
  };
  const failure = (text) => {
    ready = false;
    feedback.textContent = text;
    feedback.setAttribute("role", "alert");
    retry.hidden = false;
  };
  async function load() {
    if (disposed || busy) return;
    busy = true;
    ready = false;
    retry.hidden = true;
    disable();
    feedback.setAttribute("role", "status");
    feedback.textContent = tr("\u6B63\u5728\u8BFB\u53D6\u8BBE\u7F6E\u2026", "Loading settings\u2026");
    try {
      const settings = await context.command("load-settings", {});
      if (disposed) return;
      show(settings);
      ready = true;
      feedback.textContent = "";
    } catch {
      if (!disposed)
        failure(tr("\u8BBE\u7F6E\u8BFB\u53D6\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002", "Could not load settings. Please retry."));
    } finally {
      busy = false;
      if (!disposed) disable();
    }
  }
  form.addEventListener("submit", (event) => event.preventDefault(), { signal: events.signal });
  form.addEventListener(
    "change",
    async () => {
      if (disposed || !ready || busy) return;
      const values = Object.fromEntries(new FormData(form));
      show(values);
      busy = true;
      disable();
      feedback.textContent = tr("\u6B63\u5728\u4FDD\u5B58\u2026", "Saving\u2026");
      try {
        const saved = await context.command("save-settings", values);
        if (disposed) return;
        show(saved);
        feedback.textContent = tr("\u5DF2\u4FDD\u5B58\uFF0C\u4E0B\u4E00\u5C40\u751F\u6548", "Saved for the next round");
      } catch {
        if (!disposed)
          failure(
            tr(
              "\u4FDD\u5B58\u672A\u786E\u8BA4\uFF0C\u8BF7\u91CD\u65B0\u8BFB\u53D6\u8BBE\u7F6E\u540E\u6838\u5BF9\u3002",
              "Save not confirmed. Reload and check settings."
            )
          );
      } finally {
        busy = false;
        if (!disposed) disable();
      }
    },
    { signal: events.signal }
  );
  retry.addEventListener("click", () => void load(), { signal: events.signal });
  const cleanup = () => {
    if (disposed) return;
    disposed = true;
    events.abort();
    root.remove();
    context.signal.removeEventListener("abort", cleanup);
  };
  context.signal.addEventListener("abort", cleanup, { once: true });
  if (context.signal.aborted) cleanup();
  else void load();
  return cleanup;
}

// src/page-strings.mjs
var zh = {
  introLabel: "\u4E94\u5B50\u68CB\u80FD\u600E\u4E48\u73A9",
  introRulesTitle: "\u6807\u51C6\u89C4\u5219\uFF1A",
  introRulesDetail: "15\xD715 \u81EA\u7531\u89C4\u5219\uFF0C\u65E0\u7981\u624B\uFF0C\u5F00\u5C40\u968F\u673A\u5206\u914D\u9ED1\u767D\uFF0C\u9ED1\u68CB\u5148\u884C\u3002",
  introTurnsTitle: "\u8F6E\u6D41\u843D\u5B50\uFF1A",
  introTurnsDetail: "\u4F60\u548C\u89D2\u8272\u4EA4\u66FF\uFF0C\u70B9\u51FB\u68CB\u76D8\u4EA4\u70B9\u843D\u5B50\uFF0C\u4E5F\u53EF\u4EE5\u65B9\u5411\u952E\u79FB\u52A8\u3001\u56DE\u8F66\u843D\u5B50\u3002",
  introEngineTitle: "\u6A21\u578B\u6216\u5F15\u64CE\uFF1A",
  introEngineDetail: "\u53EF\u9009\u6A21\u578B\u72EC\u7ACB\u601D\u8003\uFF0C\u6216\u672C\u5730\u5F15\u64CE\u7ED9\u51FA\u5019\u9009\u70B9\u548C\u8BC4\u4F30\uFF0C\u6700\u7EC8\u843D\u5B50\u4ECD\u7531\u6A21\u578B\u51B3\u5B9A\u3002",
  introReplayTitle: "\u7ED3\u675F\u590D\u76D8\uFF1A",
  introReplayDetail: "\u652F\u6301\u8BA4\u8F93\u3001\u518D\u6765\u4E00\u5C40\u3001\u7D2F\u8BA1\u6BD4\u5206\uFF0C\u4E5F\u80FD\u67E5\u8BE2\u6700\u8FD1\u4E94\u5C40\u7684\u5B8C\u6574\u68CB\u8C31\u4E0E\u7ED3\u679C\u3002",
  featuresTitle: "\u63D2\u4EF6\u529F\u80FD",
  boardTitle: "\u5F00\u5C40\u4E0E\u68CB\u76D8",
  boardDetail: "15\xD715 \u81EA\u7531\u89C4\u5219\uFF0C\u968F\u673A\u9ED1\u767D\u3001\u9ED1\u68CB\u5148\u884C\uFF1B\u652F\u6301\u804A\u5929\u5165\u53E3\u548C\u5C0F\u6E38\u620F\u9762\u677F\uFF0C\u6EE1\u76D8\u65E0\u4EBA\u83B7\u80DC\u5224\u548C\u3002",
  turnsTitle: "\u8F6E\u6D41\u843D\u5B50",
  turnsDetail: "\u4F60\u70B9\u51FB\u4EA4\u70B9\u843D\u5B50\uFF0C\u65B9\u5411\u952E\u79FB\u52A8\u9009\u62E9\u3001\u56DE\u8F66\u786E\u8BA4\uFF1B\u89D2\u8272\u6839\u636E\u6700\u65B0\u5B8C\u6574\u68CB\u76D8\u9009\u62E9\u7A7A\u70B9\uFF0C\u7528\u6237\u56DE\u5408\u4FDD\u6301\u7B49\u5F85\uFF0C\u4E0D\u8BF7\u6C42\u6A21\u578B\u3002",
  winTitle: "\u80DC\u8D1F\u5224\u5B9A",
  winDetail: "\u6A2A\u3001\u7AD6\u6216\u659C\u5411\u8FDE\u7EED\u4E94\u5B50\u6216\u4EE5\u4E0A\u83B7\u80DC\uFF0C\u83B7\u80DC\u8FDE\u7EBF\u9AD8\u4EAE\uFF0C\u6700\u8FD1\u4E00\u624B\u6807\u5706\u70B9\uFF1B\u80DC\u8D1F\u4EE5\u540E\u53F0\u7ED3\u679C\u4E3A\u51C6\u3002",
  engineTitle: "\u6A21\u578B\u843D\u5B50\u4E0E\u5F15\u64CE\u8F85\u52A9",
  engineDetail: "\u9ED8\u8BA4\u53EA\u5411\u6A21\u578B\u63D0\u4F9B\u68CB\u76D8\uFF1B\u53EF\u5207\u6362\u672C\u5730\u5F15\u64CE\uFF0C\u8BA1\u7B97\u6700\u591A\u4E09\u4E2A\u5019\u9009\u843D\u70B9\u548C\u8BC4\u4F30\u5206\uFF0C\u6A21\u578B\u4ECD\u53EF\u9009\u62E9\u5176\u4ED6\u5408\u6CD5\u7A7A\u70B9\u3002\u5F15\u64CE\u8D85\u65F6\u4F1A\u4F7F\u7528\u5DF2\u5B8C\u6210\u7684\u8F83\u6D45\u5206\u6790\u3002",
  pageSettingsTitle: "\u5BF9\u5C40\u8BBE\u7F6E",
  pauseTitle: "\u6682\u505C\u4E0E\u6062\u590D",
  pauseDetail: "\u505C\u6B62\u8FD0\u884C\u3001\u6A21\u578B\u5931\u8D25\u6216\u91CD\u542F\u4F1A\u4FDD\u7559\u68CB\u76D8\uFF0C\u70B9\u51FB\u300C\u7EE7\u7EED\u5BF9\u5C40\u300D\u6062\u590D\uFF1B\u540C\u6B65\u5931\u8D25\u65F6\u7981\u6B62\u64CD\u4F5C\uFF0C\u4E0D\u81EA\u52A8\u8865\u4E0B\u68CB\u5B50\u3002",
  historyTitle: "\u5BF9\u5C40\u8BB0\u5F55",
  historyDetail: "\u6BCF\u5C40\u7ED3\u7B97\u6216\u4E3B\u52A8\u7ED3\u675F\u65F6\u5F52\u6863\uFF0C\u8BB0\u5F55\u843D\u5B50\u987A\u5E8F\u3001\u9ED1\u767D\u5F52\u5C5E\u3001\u7ED3\u679C\u548C\u6BD4\u5206\uFF1B\u6700\u8FD1\u4E94\u5C40\u53EF\u6309\u5F53\u524D\u804A\u5929\u67E5\u8BE2\uFF0C\u672A\u5B8C\u6210\u7684\u68CB\u5C40\u4E0D\u8BA1\u8F93\u8D62\u3002",
  usageTitle: "\u5F00\u59CB\u4F7F\u7528",
  usage: "\u4ECE\u804A\u5929\u53F3\u4FA7\u6253\u5F00\u300C\u5C0F\u6E38\u620F\u300D\uFF0C\u9009\u4E2D\u300C\u4E94\u5B50\u68CB\u300D\uFF0C\u70B9\u51FB\u300C\u5F00\u59CB\u5BF9\u5C40\u300D\uFF1B\u4E5F\u53EF\u4EE5\u76F4\u63A5\u8BA9\u89D2\u8272\u966A\u4F60\u4E0B\u3002\u4F60\u53EF\u4EE5\u8FD9\u6837\u8BF4\uFF1A",
  usageExample: "\u966A\u6211\u4E0B\u4E00\u76D8\u4E94\u5B50\u68CB\u5427\uFF0C\u4F60\u5148\u8D70\u3002"
};
var en = {
  introLabel: "How Gomoku works",
  introRulesTitle: "Standard rules:",
  introRulesDetail: "15\xD715 freestyle Gomoku with no forbidden moves; colors are assigned randomly and black moves first.",
  introTurnsTitle: "Take turns:",
  introTurnsDetail: "You and the character alternate; click an intersection, or use the arrow keys and Enter.",
  introEngineTitle: "Model or engine:",
  introEngineDetail: "The model can think on its own, or a local engine can suggest candidate moves and scores; the final move is still the model\u2019s choice.",
  introReplayTitle: "Review afterwards:",
  introReplayDetail: "Resign, play again, keep score, and review the full moves and results of the last five rounds.",
  featuresTitle: "Plugin features",
  boardTitle: "Board and opening",
  boardDetail: "15\xD715 freestyle; random colors and black first. Opens from chat or Mini games; a full board with no winner is a draw.",
  turnsTitle: "Alternating moves",
  turnsDetail: "Click an intersection to place a stone, or use the arrow keys and Enter. The character picks an empty point from the latest full board; your turn waits without model requests.",
  winTitle: "Win detection",
  winDetail: "Five or more stones in a row horizontally, vertically or diagonally win; the winning line is highlighted and the last move is marked. The backend result is authoritative.",
  engineTitle: "Model or engine assistance",
  engineDetail: "By default the model only receives the board. A local engine can compute up to three candidate moves and scores, while the model may still choose another legal point. A timeout falls back to the shallower completed analysis.",
  pageSettingsTitle: "Game settings",
  pauseTitle: "Pause and resume",
  pauseDetail: "Stopping the run, model failure or restart keeps the board; continue to resume. Failed synchronization blocks moves and never places stones automatically.",
  historyTitle: "Match history",
  historyDetail: "Each completed or resigned round is archived with move order, colors, result and score. The last five rounds can be queried per chat; unfinished games do not count as wins or losses.",
  usageTitle: "Start playing",
  usage: "Open Mini games from the right side of the chat, choose Gomoku and start a round, or ask the character to play. Try saying:",
  usageExample: "Let\u2019s play Gomoku. You go first."
};

// src/page.mjs
function mount2(container, context) {
  if (!context.controls) throw new Error("plugin-host-upgrade-required");
  const t = context.language.startsWith("zh") ? zh : en;
  const style = document.createElement("style");
  style.textContent = page_default;
  const root = document.createElement("div");
  root.className = "gomoku-page";
  root.innerHTML = `
    <section class="intro" aria-label="">
      <ul></ul>
    </section>
    <section class="features" aria-labelledby="gomoku-features-title">
      <h2 id="gomoku-features-title"><span class="section-icon" data-icon="blocks"></span><span class="heading-label"></span><span class="section-count"></span></h2>
      <ul></ul>
    </section>
    <section class="settings" aria-labelledby="gomoku-settings-title">
      <h2 id="gomoku-settings-title"><span class="section-icon" data-icon="link"></span><span class="heading-label"></span></h2>
      <div class="settings-body"></div>
    </section>
    <section class="usage" aria-labelledby="gomoku-usage-title">
      <h2 id="gomoku-usage-title"><span class="section-icon" data-icon="message-square"></span><span class="heading-label"></span></h2>
      <p></p>
      <blockquote></blockquote>
    </section>`;
  container.replaceChildren(style, root);
  const query = (selector) => root.querySelector(selector);
  query(".intro").setAttribute("aria-label", t.introLabel);
  const introItems = [
    [t.introRulesTitle, t.introRulesDetail],
    [t.introTurnsTitle, t.introTurnsDetail],
    [t.introEngineTitle, t.introEngineDetail],
    [t.introReplayTitle, t.introReplayDetail]
  ];
  const introList = query(".intro ul");
  for (const [title, detail] of introItems) {
    const item = document.createElement("li");
    const heading = document.createElement("strong");
    heading.textContent = title;
    const copy = document.createElement("span");
    copy.textContent = detail;
    item.append(heading, copy);
    introList.append(item);
  }
  const features = [
    { icon: "blocks", title: t.boardTitle, detail: t.boardDetail },
    { icon: "refresh-cw", title: t.turnsTitle, detail: t.turnsDetail },
    { icon: "circle-check", title: t.winTitle, detail: t.winDetail },
    { icon: "list-tree", title: t.engineTitle, detail: t.engineDetail },
    { icon: "circle-dashed", title: t.pauseTitle, detail: t.pauseDetail },
    { icon: "file-text", title: t.historyTitle, detail: t.historyDetail }
  ];
  const featureList = query(".features ul");
  for (const feature of features) {
    const item = document.createElement("li");
    const iconSlot = document.createElement("span");
    iconSlot.className = "feature-icon";
    iconSlot.dataset.icon = feature.icon;
    const copy = document.createElement("div");
    const heading = document.createElement("h3");
    heading.textContent = feature.title;
    const detail = document.createElement("p");
    detail.textContent = feature.detail;
    copy.append(heading, detail);
    item.append(iconSlot, copy);
    featureList.append(item);
  }
  query(".features h2 .heading-label").textContent = t.featuresTitle;
  query(".features h2 .section-count").textContent = String(features.length);
  query(".settings h2 .heading-label").textContent = t.pageSettingsTitle;
  const settingsCleanup = mount(query(".settings-body"), context);
  query(".usage h2 .heading-label").textContent = t.usageTitle;
  query(".usage p").textContent = t.usage;
  query(".usage blockquote").textContent = t.usageExample;
  const handles = [];
  for (const slot of root.querySelectorAll("[data-icon]")) {
    const name = slot.dataset.icon;
    if (context.controls.icons?.includes(name))
      handles.push(context.controls.mount(slot, { type: "icon", name, size: 18 }));
    else slot.hidden = true;
  }
  function cleanup() {
    settingsCleanup();
    for (const handle of handles) handle.destroy();
    container.replaceChildren();
  }
  context.signal.addEventListener("abort", cleanup, { once: true });
  return cleanup;
}
export {
  mount2 as mount
};
