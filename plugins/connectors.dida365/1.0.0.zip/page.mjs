// src/page.css
var page_default = ":host {\n  color: var(--foreground);\n  font-family: inherit;\n}\n* {\n  box-sizing: border-box;\n}\n[hidden] {\n  display: none !important;\n}\nh2 {\n  display: flex;\n  align-items: center;\n  gap: var(--ui-space-2);\n  font-size: var(--ui-text-base);\n  font-weight: 600;\n  margin: 0;\n  padding-bottom: var(--ui-space-3);\n  border-bottom: 1px solid var(--border);\n}\nh3 {\n  font-size: var(--ui-text-sm);\n  font-weight: 600;\n  margin: 0 0 var(--ui-space-1);\n}\np {\n  margin: 0;\n  font-size: var(--ui-text-sm);\n  line-height: var(--ui-leading-prose);\n  overflow-wrap: anywhere;\n}\n.section-icon,\n.feature-icon {\n  display: inline-flex;\n  flex: none;\n  color: var(--muted-foreground);\n}\n.feature-icon {\n  margin-top: 0.125rem;\n}\n.account-row {\n  display: flex;\n  align-items: center;\n  flex-wrap: wrap;\n  gap: var(--ui-space-4);\n  padding: var(--ui-space-5) 0 0;\n}\n.account-icon {\n  width: 2.25rem;\n  height: 2.25rem;\n  border: 1px solid var(--border);\n  border-radius: var(--ui-radius-md);\n  flex: none;\n}\n.account-summary {\n  flex: 1;\n  min-width: min(100%, 14rem);\n}\n.account-name {\n  display: block;\n  font-size: var(--ui-text-sm);\n  line-height: var(--ui-leading-prose);\n  overflow-wrap: anywhere;\n}\n.account-hint {\n  margin-top: var(--ui-space-1);\n  color: var(--muted-foreground);\n}\n.account-actions {\n  display: flex;\n  flex-wrap: wrap;\n  gap: var(--ui-space-2);\n}\n.account-status {\n  margin-top: var(--ui-space-4);\n  color: var(--muted-foreground);\n}\n.account-error {\n  margin-top: var(--ui-space-4);\n}\n.account-error p {\n  color: var(--destructive);\n  margin-bottom: var(--ui-space-2);\n}\n.features {\n  margin-top: var(--ui-space-8);\n}\n.features ul {\n  margin: 0;\n  padding: 0;\n  list-style: none;\n}\n.features li {\n  display: flex;\n  align-items: flex-start;\n  gap: var(--ui-space-4);\n  padding: var(--ui-space-5) 0 0;\n}\n.features p {\n  color: var(--muted-foreground);\n}\n";

// src/strings.mjs
var zh = {
  accountTitle: "\u6EF4\u7B54\u6E05\u5355\u8D26\u53F7\uFF08\u56FD\u5185\u7248\uFF09",
  featuresTitle: "\u6E05\u5355\u4E0E\u4EFB\u52A1\u80FD\u529B",
  features: [
    ["\u67E5\u770B\u6536\u96C6\u7BB1\u4E0E\u6E05\u5355", "\u8BFB\u53D6\u6536\u96C6\u7BB1\u53CA\u6240\u6709\u81EA\u5EFA\u6E05\u5355\u4E2D\u7684\u672A\u5B8C\u6210\u4EFB\u52A1\u3001\u5206\u7EC4\u4E0E\u5B50\u4EFB\u52A1\u8BE6\u60C5\u3002"],
    ["\u521B\u5EFA\u4E0E\u66F4\u65B0\u4EFB\u52A1", "\u652F\u6301\u622A\u6B62\u65E5\u671F\u3001\u5168\u5929\u63D0\u9192\u3001\u4F18\u5148\u7EA7\u3001\u91CD\u590D\u89C4\u5219\u53CA\u4EFB\u52A1\u5B8C\u6210\u4E0E\u5220\u9664\u3002"],
    ["\u7BA1\u7406\u4EFB\u52A1\u6E05\u5355", "\u6309\u9700\u65B0\u5EFA\u3001\u91CD\u547D\u540D\u3001\u5207\u6362\u89C6\u56FE\u6A21\u5F0F\u6216\u5220\u9664\u81EA\u5EFA\u4EFB\u52A1\u6E05\u5355\u3002"]
  ],
  connect: "\u8FDE\u63A5\u6EF4\u7B54\u6E05\u5355",
  continue: "\u7EE7\u7EED\u6388\u6743",
  cancel: "\u53D6\u6D88\u6388\u6743",
  disconnect: "\u65AD\u5F00\u8FDE\u63A5",
  retry: "\u91CD\u8BD5",
  loading: "\u6B63\u5728\u8BFB\u53D6\u8D26\u53F7\u2026",
  loadFailed: "\u65E0\u6CD5\u8BFB\u53D6\u8FDE\u63A5\u72B6\u6001\u3002",
  notConnected: "\u5C1A\u672A\u8FDE\u63A5\u6EF4\u7B54\u6E05\u5355",
  ready: "\u5DF2\u8FDE\u63A5",
  scope: "\u8BFB\u53D6\u548C\u7BA1\u7406\u6E05\u5355\u4E0E\u4EFB\u52A1",
  reauthorization: "\u6388\u6743\u5DF2\u5931\u6548\uFF0C\u8BF7\u65AD\u5F00\u5E76\u91CD\u65B0\u8FDE\u63A5\u3002",
  authorizing: "\u7B49\u5F85\u6EF4\u7B54\u6E05\u5355\u6388\u6743",
  authorizingHint: "\u8BF7\u5728\u7CFB\u7EDF\u6D4F\u89C8\u5668\u4E2D\u767B\u5F55\u6EF4\u7B54\u6E05\u5355\uFF08\u56FD\u5185\u7248\uFF09\u5E76\u540C\u610F\u6388\u6743\uFF0C\u5B8C\u6210\u540E\u56DE\u5230 LimeA\u3002",
  actionFailed: "\u64CD\u4F5C\u672A\u5B8C\u6210\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u540E\u91CD\u8BD5\u3002",
  vaultUnavailable: "\u7CFB\u7EDF\u51ED\u636E\u5B58\u50A8\u4E0D\u53EF\u7528\u3002",
  savedAcknowledging: "\u8D26\u53F7\u5DF2\u4FDD\u5B58\uFF0C\u6B63\u5728\u786E\u8BA4\u6388\u6743\u3002",
  recoveryHint: "\u4E0A\u6B21\u64CD\u4F5C\u4ECD\u5F85\u6838\u5BF9\u3002",
  auth: {
    failed: "\u6388\u6743\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002",
    expired: "\u6388\u6743\u5DF2\u8FC7\u671F\uFF0C\u8BF7\u91CD\u65B0\u8FDE\u63A5\u3002",
    unknown: "\u6388\u6743\u7ED3\u679C\u5F85\u6838\u5BF9\u3002",
    cancelled: "\u5DF2\u53D6\u6D88\u6388\u6743\u3002"
  },
  revocation: {
    not_requested: "\u5DF2\u65AD\u5F00\u672C\u5730\u8FDE\u63A5\u3002",
    pending: "\u5DF2\u65AD\u5F00\u672C\u5730\u8FDE\u63A5\u3002",
    confirmed: "\u5DF2\u65AD\u5F00\u5E76\u64A4\u9500\u6388\u6743\u3002",
    unknown: "\u5DF2\u65AD\u5F00\u672C\u5730\u8FDE\u63A5\u3002\u5982\u9700\u5F7B\u5E95\u64A4\u9500\uFF0C\u8BF7\u524D\u5F80\u6EF4\u7B54\u6E05\u5355\u7F51\u9875\u7AEF\u300C\u8BBE\u7F6E \u2192 \u5173\u8054\u5E94\u7528\u300D\u624B\u52A8\u79FB\u9664\u3002",
    failed: "\u5DF2\u65AD\u5F00\u672C\u5730\u8FDE\u63A5\u3002\u8BF7\u524D\u5F80\u6EF4\u7B54\u6E05\u5355\u7F51\u9875\u7AEF\u300C\u8BBE\u7F6E \u2192 \u5173\u8054\u5E94\u7528\u300D\u624B\u52A8\u79FB\u9664\u6388\u6743\u3002"
  }
};
var en = {
  accountTitle: "Dida365 account (CN)",
  featuresTitle: "Lists & tasks",
  features: [
    ["Inspect Inbox & lists", "Read active tasks, columns and checklist items from Inbox or any list."],
    ["Create & update tasks", "Add tasks with due dates, priority, repeat rules, and complete or delete tasks."],
    ["Manage lists", "Create, update or remove custom task and note lists."]
  ],
  connect: "Connect Dida365",
  continue: "Continue authorization",
  cancel: "Cancel",
  disconnect: "Disconnect",
  retry: "Retry",
  loading: "Loading account\u2026",
  loadFailed: "Could not load connection.",
  notConnected: "Dida365 is disconnected",
  ready: "Connected",
  scope: "Read and manage lists and tasks",
  reauthorization: "Authorization expired. Disconnect and reconnect.",
  authorizing: "Waiting for Dida365",
  authorizingHint: "Sign in and approve Dida365 access in your browser, then return to LimeA.",
  actionFailed: "Operation failed. Check your connection and retry.",
  vaultUnavailable: "System credential storage is unavailable.",
  savedAcknowledging: "Account saved. Confirming authorization.",
  recoveryHint: "The previous operation is awaiting review.",
  auth: {
    failed: "Authorization failed.",
    expired: "Authorization expired. Reconnect.",
    unknown: "Authorization outcome is unknown.",
    cancelled: "Authorization cancelled."
  },
  revocation: {
    not_requested: "Disconnected locally.",
    pending: "Disconnected locally.",
    confirmed: "Disconnected and revoked.",
    unknown: "Disconnected locally. Remove LimeA under Dida365 Settings -> Connected Apps if needed.",
    failed: "Disconnected locally. Remove LimeA under Dida365 Settings -> Connected Apps."
  }
};

// src/page.mjs
function mount(container, context) {
  if (!context.connections || !context.controls) throw new Error("plugin-host-upgrade-required");
  const t = context.language.startsWith("zh") ? zh : en;
  const style = document.createElement("style");
  style.textContent = page_default;
  const root = document.createElement("div");
  root.className = "dida365-page";
  root.innerHTML = `<section class="account" aria-labelledby="account-title">
    <h2 id="account-title"></h2>
    <div class="account-row"><img class="account-icon" alt=""><div class="account-summary"><strong class="account-name"></strong><p class="account-hint"></p></div>
      <div class="account-actions"><span data-action="authorize"></span><span data-action="resume"></span><span data-action="cancel"></span><span data-action="disconnect"></span></div></div>
    <p role="status" class="account-status"></p><div role="alert" class="account-error"><p></p><span data-action="retry"></span></div></section>
    <section class="features"><h2><span class="section-icon" data-icon="blocks"></span><span class="heading-label"></span></h2><ul></ul></section>`;
  container.replaceChildren(style, root);
  const query = (selector) => root.querySelector(selector);
  query("#account-title").textContent = t.accountTitle;
  query(".account-icon").src = new URL("assets/icon.png", context.resourceBase).href;
  query(".features h2 .heading-label").textContent = t.featuresTitle;
  const featureIcons = ["search", "check-square", "list-tree"];
  for (const [index, [title, detail]] of t.features.entries()) {
    const row = document.createElement("li"), icon = document.createElement("span"), section = document.createElement("div"), h = document.createElement("h3"), p = document.createElement("p");
    h.textContent = title;
    p.textContent = detail;
    icon.className = "feature-icon";
    icon.dataset.icon = featureIcons[index];
    section.append(h, p);
    row.append(icon, section);
    query(".features ul").append(row);
  }
  let view, pending = false, polling = false, timer, disposed = false, error = "";
  const handles = /* @__PURE__ */ new Map();
  const iconHandles = [];
  for (const slot of root.querySelectorAll("[data-icon]")) {
    const name = slot.dataset.icon;
    if (context.controls.icons?.includes(name)) {
      iconHandles.push(context.controls.mount(slot, { type: "icon", name, size: 18 }));
    } else slot.hidden = true;
  }
  const alive = () => !disposed && !context.signal.aborted;
  const labels = {
    authorize: t.connect,
    resume: t.continue,
    cancel: t.cancel,
    disconnect: t.disconnect,
    retry: t.retry
  };
  const actionIcons = {
    authorize: "external-link",
    resume: "external-link",
    disconnect: "unplug"
  };
  const buttonIcon = (action) => context.controls.icons?.includes(actionIcons[action]) ? { icon: actionIcons[action] } : {};
  for (const [action, label] of Object.entries(labels)) {
    const slot = query(`[data-action="${action}"]`);
    handles.set(
      action,
      context.controls.mount(slot, {
        type: "button",
        label,
        ...buttonIcon(action),
        variant: action === "authorize" ? "default" : "outline",
        onPress: () => void perform(action)
      })
    );
  }
  function render() {
    if (!alive()) return;
    const c = view?.connection, f = view?.authorization;
    const authorizing = f && ["preparing", "authorizing"].includes(f.status);
    const connected = c?.status === "connected";
    query(".account-name").textContent = !view ? t.loading : authorizing ? t.authorizing : connected ? c.workspaceName : c?.status === "reauthorization_required" ? t.reauthorization : t.notConnected;
    query(".account-hint").textContent = authorizing ? t.authorizingHint : connected ? `${t.ready} \xB7 ${t.scope}` : t.scope;
    const shown = {
      authorize: Boolean(
        view && (!c || c.status === "disconnected") && !authorizing && f?.status !== "persisted"
      ),
      resume: Boolean(authorizing),
      cancel: Boolean(authorizing),
      disconnect: Boolean(c && c.status !== "disconnected"),
      retry: Boolean(error)
    };
    for (const [action, handle] of handles) {
      query(`[data-action="${action}"]`).hidden = !shown[action];
      handle.update({
        type: "button",
        label: labels[action],
        ...buttonIcon(action),
        variant: action === "authorize" ? "default" : "outline",
        disabled: pending,
        onPress: () => void perform(action)
      });
    }
    let status = "";
    if (c?.status === "disconnected") status = t.revocation[c.remoteRevocation];
    else if (f?.status === "persisted") status = t.savedAcknowledging;
    else if (f && ["failed", "expired", "unknown", "cancelled"].includes(f.status))
      status = t.auth[f.status];
    else if (c?.error || f?.error) status = t.recoveryHint;
    query(".account-status").textContent = status;
    query(".account-status").hidden = !status;
    query(".account-error").hidden = !error;
    query(".account-error p").textContent = error;
    query(".account").setAttribute("aria-busy", String(pending || !view));
  }
  function schedule() {
    clearTimeout(timer);
    if (alive() && (view?.operation || view?.authorization?.pending))
      timer = setTimeout(() => void load(), 2e3);
  }
  async function load() {
    if (!alive() || pending || polling) return;
    polling = true;
    try {
      const next = await context.connections.request({ action: "view" });
      if (alive() && (!view || next.revision >= view.revision)) {
        view = next;
        error = "";
      }
    } catch {
      if (alive()) error = t.loadFailed;
    } finally {
      polling = false;
      if (alive()) {
        render();
        schedule();
      }
    }
  }
  async function perform(action) {
    if (!alive() || pending) return;
    if (action === "retry") {
      await load();
      return;
    }
    pending = true;
    error = "";
    render();
    try {
      const next = await context.connections.request({ action });
      if (alive() && (!view || next.revision >= view.revision)) view = next;
    } catch (e) {
      if (alive())
        error = e?.code === "connection-vault-unavailable" ? t.vaultUnavailable : t.actionFailed;
    } finally {
      pending = false;
      if (alive()) {
        render();
        schedule();
      }
    }
  }
  const unsubscribe = context.connections.subscribe((next) => {
    if (alive() && (!view || next.revision >= view.revision)) {
      view = next;
      render();
      schedule();
    }
  });
  const onFocus = () => void load();
  window.addEventListener("focus", onFocus);
  function cleanup() {
    disposed = true;
    clearTimeout(timer);
    unsubscribe();
    window.removeEventListener("focus", onFocus);
    for (const handle of handles.values()) handle.destroy();
    for (const handle of iconHandles) handle.destroy();
    container.replaceChildren();
  }
  context.signal.addEventListener("abort", cleanup, { once: true });
  render();
  void load();
  return cleanup;
}
export {
  mount
};
